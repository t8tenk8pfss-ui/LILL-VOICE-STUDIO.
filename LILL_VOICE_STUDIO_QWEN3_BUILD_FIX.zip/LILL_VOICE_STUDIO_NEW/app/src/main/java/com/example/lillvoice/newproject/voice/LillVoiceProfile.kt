package com.example.lillvoice.newproject.voice

/**
 * LILL VOICE PROFILE
 * Постоянный характер голоса Лил.
 */
data class LillVoiceProfile(

    val baseSpeed: Float = 1.0f,
    val basePitch: Float = 0.96f,
    val warmth: Float = 0.75f,
    val softness: Float = 0.80f,
    val expressiveness: Float = 0.85f,
    val breathiness: Float = 0.15f,
    val depth: Float = 0.65f,

    val minSpeed: Float = 0.65f,
    val maxSpeed: Float = 1.25f,

    val minPitch: Float = 0.75f,
    val maxPitch: Float = 1.25f
) {

    data class VoiceSettings(
        val speed: Float,
        val pitch: Float,
        val warmth: Float,
        val softness: Float,
        val expressiveness: Float,
        val breathiness: Float,
        val depth: Float
    )

    fun settingsFor(
        emotion: LillEmotionEngine.Emotion,
        intensity: Float = 0.5f
    ): VoiceSettings {

        val strength = intensity.coerceIn(0f, 1f)

        val emotionSpeed = when (emotion) {
            LillEmotionEngine.Emotion.CALM -> 1.0f
            LillEmotionEngine.Emotion.JOY -> 1.08f
            LillEmotionEngine.Emotion.SADNESS -> 0.84f
            LillEmotionEngine.Emotion.TENDERNESS -> 0.90f
            LillEmotionEngine.Emotion.IRONY -> 0.97f
            LillEmotionEngine.Emotion.ANGER -> 1.10f
        }

        val emotionPitch = when (emotion) {
            LillEmotionEngine.Emotion.CALM -> 1.0f
            LillEmotionEngine.Emotion.JOY -> 1.07f
            LillEmotionEngine.Emotion.SADNESS -> 0.93f
            LillEmotionEngine.Emotion.TENDERNESS -> 0.97f
            LillEmotionEngine.Emotion.IRONY -> 1.02f
            LillEmotionEngine.Emotion.ANGER -> 1.06f
        }

        val emotionWarmth = when (emotion) {
            LillEmotionEngine.Emotion.CALM -> 0.05f
            LillEmotionEngine.Emotion.JOY -> 0.10f
            LillEmotionEngine.Emotion.SADNESS -> 0.02f
            LillEmotionEngine.Emotion.TENDERNESS -> 0.20f
            LillEmotionEngine.Emotion.IRONY -> -0.05f
            LillEmotionEngine.Emotion.ANGER -> -0.15f
        }

        val emotionSoftness = when (emotion) {
            LillEmotionEngine.Emotion.CALM -> 0.05f
            LillEmotionEngine.Emotion.JOY -> 0.0f
            LillEmotionEngine.Emotion.SADNESS -> 0.08f
            LillEmotionEngine.Emotion.TENDERNESS -> 0.15f
            LillEmotionEngine.Emotion.IRONY -> -0.05f
            LillEmotionEngine.Emotion.ANGER -> -0.20f
        }

        return VoiceSettings(
            speed = (baseSpeed * emotionSpeed)
                .coerceIn(minSpeed, maxSpeed),

            pitch = (basePitch * emotionPitch)
                .coerceIn(minPitch, maxPitch),

            warmth = (warmth + emotionWarmth * strength)
                .coerceIn(0f, 1f),

            softness = (softness + emotionSoftness * strength)
                .coerceIn(0f, 1f),

            expressiveness = expressiveness
                .coerceIn(0f, 1f),

            breathiness = breathiness
                .coerceIn(0f, 1f),

            depth = depth.coerceIn(0f, 1f)
        )
    }

    companion object {
        fun default(): LillVoiceProfile {
            return LillVoiceProfile()
        }
    }
}
