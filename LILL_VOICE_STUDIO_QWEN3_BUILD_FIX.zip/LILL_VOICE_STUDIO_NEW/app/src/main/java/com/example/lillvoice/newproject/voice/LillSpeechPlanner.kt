package com.example.lillvoice.newproject.voice

class LillSpeechPlanner {

    enum class PauseType {
        NONE,
        SHORT,
        MEDIUM,
        LONG
    }

    data class SpeechSegment(
        val text: String,
        val emotion: LillEmotionEngine.Emotion,
        val intensity: Float,
        val speed: Float,
        val pitch: Float,
        val pauseAfterMs: Long,
        val emphasis: Boolean
    )

    data class SpeechPlan(
        val segments: List<SpeechSegment>,
        val estimatedDurationMs: Long
    )

    private val textBrain = LillTextBrain()

    fun createPlan(text: String): SpeechPlan {

        val normalized = text.trim()

        if (normalized.isEmpty()) {
            return SpeechPlan(
                segments = emptyList(),
                estimatedDurationMs = 0L
            )
        }

        val analysis = textBrain.analyze(normalized)

        val sentenceTexts = analysis.sentences
            .map { it.text.trim() }
            .filter { it.isNotEmpty() }

        // Резервный вариант: не допускаем пустой план
        // для непустого входного текста.
        val safeTexts = if (sentenceTexts.isEmpty()) {
            listOf(normalized)
        } else {
            sentenceTexts
        }

        val segments = safeTexts.map { sentenceText ->

            SpeechSegment(
                text = sentenceText,
                emotion = LillEmotionEngine.Emotion.CALM,
                intensity = 0.5f,
                speed = 1.0f,
                pitch = 1.0f,
                pauseAfterMs = 0L,
                emphasis = false
            )
        }

        val estimatedDuration = segments.sumOf { segment ->
            (segment.text.length * 65.0).toLong()
        }

        return SpeechPlan(
            segments = segments,
            estimatedDurationMs = estimatedDuration
        )
    }
}
