package com.example.lillvoice.newproject.voice

import java.io.ByteArrayOutputStream

/**
 * LILL WAV PROCESSOR
 *
 * Чтение, обработка и сборка WAV-файлов.
 *
 * Поддержка:
 * - PCM 16-bit;
 * - Mono;
 * - Stereo;
 * - сохранение частоты дискретизации;
 * - сохранение количества каналов;
 * - обработка каналов по отдельности;
 * - сохранение исходной длительности.
 */
class LillWavProcessor {

    data class WavInfo(
        val sampleRate: Int,
        val channels: Int,
        val bitsPerSample: Int,
        val audioFormat: Int,
        val dataSize: Int,
        val totalSamples: Int
    )

    data class ProcessingResult(
        val wavData: ByteArray,
        val originalInfo: WavInfo,
        val processedSamples: Int,
        val success: Boolean,
        val message: String
    )

    private val prosodyApplier = LillProsodyApplier()

    /**
     * Получение информации о WAV.
     */
    fun inspectWav(input: ByteArray): WavInfo {

        val chunks = parseChunks(input)

        val format = chunks.format
            ?: throw IllegalArgumentException(
                "WAV: отсутствует блок fmt"
            )

        val data = chunks.audio
            ?: throw IllegalArgumentException(
                "WAV: отсутствует блок data"
            )

        val audioFormat = readU16(input, format)
        val channels = readU16(input, format + 2)
        val sampleRate = readInt(input, format + 4)
        val blockAlign = readU16(input, format + 12)
        val bitsPerSample = readU16(input, format + 14)

        require(channels > 0 && sampleRate > 0) {
            "WAV: неверные параметры аудио"
        }

        require(blockAlign > 0) {
            "WAV: неверный blockAlign"
        }

        return WavInfo(
            sampleRate = sampleRate,
            channels = channels,
            bitsPerSample = bitsPerSample,
            audioFormat = audioFormat,
            dataSize = chunks.audioSize,
            totalSamples = chunks.audioSize / blockAlign
        )
    }

    /**
     * Основная обработка WAV.
     */
    fun processWav(
        input: ByteArray,
        plan: LillProsodyEngine.ProsodyPlan,
        settings: LillVoiceProcessor.AudioSettings
    ): ProcessingResult {

        val info = inspectWav(input)

        require(info.audioFormat == 1) {
            "Поддерживается только PCM WAV"
        }

        require(info.bitsPerSample == 16) {
            "Поддерживается только PCM 16-bit"
        }

        require(info.channels == 1 || info.channels == 2) {
            "Поддерживаются только Mono и Stereo"
        }

        require(info.sampleRate in 8000..192000) {
            "WAV: неподдерживаемая частота дискретизации"
        }

        val chunks = parseChunks(input)

        val dataOffset = chunks.audio
            ?: throw IllegalArgumentException(
                "WAV: отсутствует блок data"
            )

        val channelCount = info.channels
        val sampleCount = chunks.audioSize / (2 * channelCount)

        require(chunks.audioSize % (2 * channelCount) == 0) {
            "WAV: некорректный размер аудиоданных"
        }

        val outputChannels = Array(channelCount) {
            FloatArray(sampleCount)
        }

        // Извлечение каналов.
        for (sampleIndex in 0 until sampleCount) {

            for (channel in 0 until channelCount) {

                val byteIndex = dataOffset +
                    (sampleIndex * channelCount + channel) * 2

                val pcm = readU16(input, byteIndex).toShort()

                outputChannels[channel][sampleIndex] =
                    pcm.toFloat() / 32768f
            }
        }

        // Обработка каждого канала отдельно.
        val processedChannels = Array(channelCount) { channel ->

            prosodyApplier.apply(
                input = outputChannels[channel],
                plan = plan,
                settings = settings,
                sampleRate = info.sampleRate
            )
        }

        // Проверка результата обработки.
        for (channel in processedChannels.indices) {

            require(processedChannels[channel].size == sampleCount) {
                "Ошибка обработки: изменилась длина канала $channel"
            }
        }

        // Сборка PCM.
        val outputPcm = ByteArrayOutputStream(
            sampleCount * channelCount * 2
        )

        for (sampleIndex in 0 until sampleCount) {

            for (channel in 0 until channelCount) {

                val sample = processedChannels[channel][sampleIndex]
                    .coerceIn(-1f, 1f)

                val pcm = (
                    sample * 32767f
                ).toInt().coerceIn(-32768, 32767)

                writeShort(outputPcm, pcm)
            }
        }

        val outputData = outputPcm.toByteArray()

        val outputWav = createWav(
            pcmData = outputData,
            sampleRate = info.sampleRate,
            channels = info.channels,
            bitsPerSample = info.bitsPerSample
        )

        return ProcessingResult(
            wavData = outputWav,
            originalInfo = info,
            processedSamples = sampleCount,
            success = true,
            message = "WAV успешно обработан"
        )
    }

    /**
     * Обработка WAV-файла с сохранением результата.
     */
    fun processFile(
        inputFile: java.io.File,
        outputFile: java.io.File,
        plan: LillProsodyEngine.ProsodyPlan,
        settings: LillVoiceProcessor.AudioSettings
    ): ProcessingResult {

        require(inputFile.exists()) {
            "Исходный WAV-файл не найден"
        }

        val input = inputFile.readBytes()

        val result = processWav(
            input = input,
            plan = plan,
            settings = settings
        )

        outputFile.writeBytes(result.wavData)

        return result.copy(
            message = "Файл сохранён: ${outputFile.name}"
        )
    }

    /**
     * Создание стандартного PCM WAV.
     */
    private fun createWav(
        pcmData: ByteArray,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ): ByteArray {

        val output = ByteArrayOutputStream()

        val byteRate = sampleRate *
            channels *
            bitsPerSample / 8

        val blockAlign = channels *
            bitsPerSample / 8

        writeText(output, "RIFF")
        writeInt(output, 36 + pcmData.size)

        writeText(output, "WAVE")

        writeText(output, "fmt ")
        writeInt(output, 16)

        writeShort(output, 1)
        writeShort(output, channels)

        writeInt(output, sampleRate)
        writeInt(output, byteRate)

        writeShort(output, blockAlign)
        writeShort(output, bitsPerSample)

        writeText(output, "data")
        writeInt(output, pcmData.size)

        output.write(pcmData)

        return output.toByteArray()
    }

    /**
     * Поиск блоков WAV.
     */
    private fun parseChunks(input: ByteArray): ChunkInfo {

        require(input.size >= 44) {
            "Некорректный WAV: файл слишком короткий"
        }

        require(readText(input, 0, 4) == "RIFF") {
            "Некорректный RIFF"
        }

        require(readText(input, 8, 4) == "WAVE") {
            "Некорректный формат WAVE"
        }

        var position = 12

        var formatOffset: Int? = null
        var audioOffset: Int? = null
        var audioSize = 0

        while (position + 8 <= input.size) {

            val chunkName = readText(
                input,
                position,
                4
            )

            val chunkSize = readInt(
                input,
                position + 4
            )

            require(chunkSize >= 0) {
                "WAV: некорректный размер блока"
            }

            val contentStart = position + 8
            val contentEnd = contentStart.toLong() +
                chunkSize.toLong()

            require(contentEnd <= input.size) {
                "WAV: повреждённый блок $chunkName"
            }

            when (chunkName) {

                "fmt " -> {
                    formatOffset = contentStart
                }

                "data" -> {
                    audioOffset = contentStart
                    audioSize = chunkSize
                }
            }

            position = contentEnd.toInt() +
                (chunkSize and 1)

            if (formatOffset != null &&
                audioOffset != null
            ) {
                break
            }
        }

        return ChunkInfo(
            format = formatOffset,
            audio = audioOffset,
            audioSize = audioSize
        )
    }

    private data class ChunkInfo(
        val format: Int?,
        val audio: Int?,
        val audioSize: Int
    )

    private fun readU16(
        data: ByteArray,
        offset: Int
    ): Int {

        return (data[offset].toInt() and 0xFF) or
            ((data[offset + 1].toInt() and 0xFF) shl 8)
    }

    private fun readInt(
        data: ByteArray,
        offset: Int
    ): Int {

        return (data[offset].toInt() and 0xFF) or
            ((data[offset + 1].toInt() and 0xFF) shl 8) or
            ((data[offset + 2].toInt() and 0xFF) shl 16) or
            ((data[offset + 3].toInt() and 0xFF) shl 24)
    }

    private fun readText(
        data: ByteArray,
        offset: Int,
        length: Int
    ): String {

        return String(
            data,
            offset,
            length,
            Charsets.US_ASCII
        )
    }

    private fun writeShort(
        output: ByteArrayOutputStream,
        value: Int
    ) {

        output.write(value and 0xFF)
        output.write((value shr 8) and 0xFF)
    }

    private fun writeInt(
        output: ByteArrayOutputStream,
        value: Int
    ) {

        output.write(value and 0xFF)
        output.write((value shr 8) and 0xFF)
        output.write((value shr 16) and 0xFF)
        output.write((value shr 24) and 0xFF)
    }

    private fun writeText(
        output: ByteArrayOutputStream,
        value: String
    ) {

        output.write(
            value.toByteArray(Charsets.US_ASCII)
        )
    }
}
