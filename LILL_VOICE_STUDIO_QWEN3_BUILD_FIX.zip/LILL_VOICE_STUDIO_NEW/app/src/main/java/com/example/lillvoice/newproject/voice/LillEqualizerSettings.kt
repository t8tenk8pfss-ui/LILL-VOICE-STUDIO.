package com.example.lillvoice.newproject.voice

import android.content.Context

/**
 * LILL EQUALIZER SETTINGS
 *
 * Хранение пользовательских настроек эквалайзера.
 */
class LillEqualizerSettings(context: Context) {

    private val preferences = context.applicationContext
        .getSharedPreferences(
            "lill_equalizer_settings",
            Context.MODE_PRIVATE
        )

    companion object {
        private const val KEY_ENABLED = "enabled"
        private const val KEY_PREAMP = "preamp"
        private const val KEY_PRESET = "preset"
        private const val KEY_BAND_PREFIX = "band_"

        const val BAND_COUNT = 10

        val PRESETS = listOf(
            "Пользовательский",
            "Ровный",
            "Бас",
            "Глубокий бас",
            "Рок",
            "Металл",
            "Вокал",
            "Классика",
            "Электронная музыка",
            "Тихий вечер"
        )

        private val PRESET_VALUES = arrayOf(
            floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
            floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
            floatArrayOf(5f, 4f, 3f, 1f, 0f, 0f, 1f, 2f, 2f, 2f),
            floatArrayOf(7f, 6f, 4f, 2f, 0f, -1f, 0f, 1f, 1f, 1f),
            floatArrayOf(4f, 3f, 1f, -1f, -1f, 1f, 3f, 4f, 4f, 3f),
            floatArrayOf(5f, 4f, 2f, 0f, -1f, 2f, 4f, 5f, 4f, 3f),
            floatArrayOf(-2f, -1f, 0f, 1f, 3f, 4f, 3f, 2f, 1f, 0f),
            floatArrayOf(3f, 2f, 1f, 0f, -1f, -1f, 0f, 2f, 3f, 3f),
            floatArrayOf(4f, 3f, 1f, 0f, -1f, 1f, 2f, 3f, 4f, 4f),
            floatArrayOf(-2f, -1f, 0f, 1f, 2f, 2f, 1f, 0f, -1f, -2f)
        )
    }

    fun isEnabled(): Boolean {
        return preferences.getBoolean(KEY_ENABLED, false)
    }

    fun setEnabled(enabled: Boolean) {
        preferences.edit()
            .putBoolean(KEY_ENABLED, enabled)
            .apply()
    }

    fun getBandLevel(index: Int): Float {
        if (index !in 0 until BAND_COUNT) return 0f

        return preferences.getFloat(
            KEY_BAND_PREFIX + index,
            0f
        )
    }

    fun setBandLevel(index: Int, value: Float) {
        if (index !in 0 until BAND_COUNT) return

        preferences.edit()
            .putFloat(
                KEY_BAND_PREFIX + index,
                value.coerceIn(-12f, 12f)
            )
            .putString(KEY_PRESET, PRESETS[0])
            .apply()
    }

    fun getAllBandLevels(): FloatArray {
        return FloatArray(BAND_COUNT) { index ->
            getBandLevel(index)
        }
    }

    fun setAllBandLevels(values: FloatArray) {
        val editor = preferences.edit()

        for (index in 0 until BAND_COUNT) {
            val value = values.getOrElse(index) { 0f }

            editor.putFloat(
                KEY_BAND_PREFIX + index,
                value.coerceIn(-12f, 12f)
            )
        }

        editor.putString(KEY_PRESET, PRESETS[0])
        editor.apply()
    }

    fun getPreamp(): Float {
        return preferences.getFloat(KEY_PREAMP, 0f)
    }

    fun setPreamp(value: Float) {
        preferences.edit()
            .putFloat(
                KEY_PREAMP,
                value.coerceIn(-12f, 12f)
            )
            .apply()
    }

    fun getPreset(): String {
        return preferences.getString(
            KEY_PRESET,
            PRESETS[1]
        ) ?: PRESETS[1]
    }

    fun applyPreset(name: String): Boolean {
        val index = PRESETS.indexOf(name)

        if (index < 0) return false

        val values = PRESET_VALUES[index]
        val editor = preferences.edit()

        for (band in 0 until BAND_COUNT) {
            editor.putFloat(
                KEY_BAND_PREFIX + band,
                values[band]
            )
        }

        editor.putString(KEY_PRESET, name)
        editor.apply()

        return true
    }

    fun reset() {
        val editor = preferences.edit()

        for (index in 0 until BAND_COUNT) {
            editor.putFloat(
                KEY_BAND_PREFIX + index,
                0f
            )
        }

        editor.putFloat(KEY_PREAMP, 0f)
        editor.putString(KEY_PRESET, PRESETS[1])
        editor.apply()
    }
}
