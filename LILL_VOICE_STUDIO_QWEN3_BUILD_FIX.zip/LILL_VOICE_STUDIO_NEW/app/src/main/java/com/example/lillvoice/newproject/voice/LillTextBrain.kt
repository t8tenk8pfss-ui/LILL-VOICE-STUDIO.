package com.example.lillvoice.newproject.voice

/**
 * LILL VOICE ENGINE
 * Модуль анализа текста.
 *
 * Подготавливает текст для эмоционального
 * движка и планировщика речи.
 */
class LillTextBrain {

    data class TextAnalysis(
        val originalText: String,
        val sentences: List<Sentence>,
        val totalCharacters: Int,
        val totalWords: Int
    )

    data class Sentence(
        val text: String,
        val isQuestion: Boolean,
        val isExclamation: Boolean,
        val isEllipsis: Boolean,
        val isShort: Boolean,
        val containsPause: Boolean
    )

    fun analyze(text: String): TextAnalysis {

        val cleanedText = text
            .replace(Regex("\\s+"), " ")
            .trim()

        if (cleanedText.isEmpty()) {
            return TextAnalysis(
                originalText = text,
                sentences = emptyList(),
                totalCharacters = 0,
                totalWords = 0
            )
        }

        val sentences = splitSentences(cleanedText)

        return TextAnalysis(
            originalText = text,
            sentences = sentences,
            totalCharacters = cleanedText.length,
            totalWords = cleanedText
                .split(Regex("\\s+"))
                .count { it.isNotBlank() }
        )
    }

    private fun splitSentences(text: String): List<Sentence> {

        val parts = Regex(
            """[^.!?…]+(?:[.!?…]+|$)"""
        ).findAll(text)

        return parts.mapNotNull { match ->

            val sentenceText = match.value.trim()

            if (sentenceText.isEmpty()) {
                return@mapNotNull null
            }

            Sentence(
                text = sentenceText,
                isQuestion = sentenceText.endsWith("?"),
                isExclamation = sentenceText.endsWith("!"),
                isEllipsis = sentenceText.endsWith("…") ||
                    sentenceText.endsWith("..."),
                isShort = sentenceText.length < 35,
                containsPause = sentenceText.contains(",") ||
                    sentenceText.contains(";") ||
                    sentenceText.contains(":")
            )

        }.toList()
    }
}
