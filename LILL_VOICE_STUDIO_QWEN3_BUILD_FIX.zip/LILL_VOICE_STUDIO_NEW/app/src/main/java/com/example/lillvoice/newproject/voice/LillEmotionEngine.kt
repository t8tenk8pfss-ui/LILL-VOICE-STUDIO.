package com.example.lillvoice.newproject.voice

class LillEmotionEngine {

    enum class Emotion {
        CALM,
        JOY,
        SADNESS,
        TENDERNESS,
        IRONY,
        ANGER
    }

    data class EmotionResult(
        val emotion: Emotion,
        val intensity: Float,
        val confidence: Float
    )

    private val joyWords = listOf(
        "рад", "рада", "счастлив", "счастлива",
        "ура", "прекрасно", "замечательно",
        "класс", "супер", "великолепно",
        "ахуенно", "круто", "обожаю"
    )

    private val sadnessWords = listOf(
        "грустно", "печально", "одиноко",
        "тоскливо", "больно", "потерял",
        "потеряла", "скучаю", "плачу",
        "слёзы", "слезы", "пустота"
    )

    private val tendernessWords = listOf(
        "люблю", "дорогой", "дорогая",
        "милый", "милая", "родной",
        "родная", "нежность", "обнимаю",
        "целую", "солнышко", "котик"
    )

    private val ironyWords = listOf(
        "ага", "конечно", "ну да",
        "смешно", "прекрасно", "гениально",
        "разумеется", "якобы", "сарказм"
    )

    private val angerWords = listOf(
        "злюсь", "бесит", "ненавижу",
        "ярость", "достало", "отстань",
        "чёрт", "черт", "блять", "блядь",
        "сука", "нахуй"
    )

    fun analyze(text: String): EmotionResult {

        val normalized = text.lowercase()
        val words = normalized
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.isNotBlank() }

        if (words.isEmpty()) {
            return neutralResult()
        }

        val scores = mutableMapOf(
            Emotion.JOY to 0,
            Emotion.SADNESS to 0,
            Emotion.TENDERNESS to 0,
            Emotion.IRONY to 0,
            Emotion.ANGER to 0
        )

        val dictionaries = mapOf(
            Emotion.JOY to joyWords,
            Emotion.SADNESS to sadnessWords,
            Emotion.TENDERNESS to tendernessWords,
            Emotion.IRONY to ironyWords,
            Emotion.ANGER to angerWords
        )

        for ((emotion, dictionary) in dictionaries) {
            for (phrase in dictionary) {
                if (normalized.contains(phrase)) {
                    scores[emotion] = scores.getValue(emotion) + 1
                }
            }
        }

        if (normalized.contains("!")) {
            scores[Emotion.JOY] =
                scores.getValue(Emotion.JOY) + 1
        }

        if (normalized.contains("...") ||
            normalized.contains("…")) {
            scores[Emotion.SADNESS] =
                scores.getValue(Emotion.SADNESS) + 1
        }

        val winner = scores.maxByOrNull { it.value }
            ?: return neutralResult()

        val maxScore = winner.value

        if (maxScore == 0) {
            return neutralResult()
        }

        val totalScore = scores.values.sum().coerceAtLeast(1)

        val confidence = (
            maxScore.toFloat() / totalScore
        ).coerceIn(0f, 1f)

        val intensity = (
            0.45f + maxScore * 0.12f
        ).coerceIn(0.45f, 1f)

        return EmotionResult(
            emotion = winner.key,
            intensity = intensity,
            confidence = confidence
        )
    }

    private fun neutralResult() = EmotionResult(
        emotion = Emotion.CALM,
        intensity = 0.5f,
        confidence = 1f
    )
}
