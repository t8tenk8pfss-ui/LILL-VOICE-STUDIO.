package com.example.lillvoice.newproject.voice

import android.content.Context
import com.qwen.tts.studio.engine.QwenEngine
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/**
 * Qwen3-TTS local runtime.
 * Does not call LillSpeechCore, LillProsodyApplier or LillWavProcessor.
 * All callbacks are invoked on the calling thread.
 */
class QwenLocalTts(context: Context) : AutoCloseable {
    companion object {
        const val TALKER = "qwen-talker-0.6b-base-Q4_K_M.gguf"
        const val TOKENIZER = "qwen-tokenizer-12hz-Q4_K_M.gguf"
        private const val BASE =
            "https://huggingface.co/Serveurperso/Qwen3-TTS-GGUF/resolve/main/"
        private const val TALKER_SIZE = 628_905_056L
        private const val TOKENIZER_SIZE = 254_974_752L
    }

    data class DownloadState(
        val fileName: String,
        val downloaded: Long,
        val total: Long
    ) {
        val percent: Int
            get() = if (total > 0) ((downloaded * 100) / total).toInt() else 0
    }

    data class Audio(
        val samples: FloatArray,
        val sampleRate: Int,
        val durationMs: Long
    )

    private val appContext = context.applicationContext
    val modelDirectory: File =
        File(appContext.filesDir, "qwen3-tts-models")
    private var engine: QwenEngine? = null
    @Volatile private var cancelDownload = false

    fun isModelDownloaded(): Boolean {
        val talker = File(modelDirectory, TALKER)
        val tokenizer = File(modelDirectory, TOKENIZER)
        return talker.isFile && talker.length() == TALKER_SIZE &&
            tokenizer.isFile && tokenizer.length() == TOKENIZER_SIZE
    }

    fun modelBytesDownloaded(): Long {
        return listOf(TALKER, TOKENIZER).sumOf {
            File(modelDirectory, it).takeIf { file -> file.exists() }?.length() ?: 0L
        }
    }

    fun cancelDownload() {
        cancelDownload = true
    }

    @Throws(Exception::class)
    fun downloadModel(
        onProgress: (DownloadState) -> Unit
    ) {
        cancelDownload = false
        modelDirectory.mkdirs()
        downloadOne(TOKENIZER, TOKENIZER_SIZE, onProgress)
        downloadOne(TALKER, TALKER_SIZE, onProgress)
    }

    private fun downloadOne(
        name: String,
        expectedSize: Long,
        onProgress: (DownloadState) -> Unit
    ) {
        val target = File(modelDirectory, name)
        if (target.isFile && target.length() == expectedSize) {
            onProgress(DownloadState(name, expectedSize, expectedSize))
            return
        }

        val partial = File(modelDirectory, "$name.part")
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(BASE + name + "?download=true").openConnection()
                as HttpURLConnection).apply {
                connectTimeout = 30_000
                readTimeout = 60_000
                requestMethod = "GET"
                instanceFollowRedirects = true
                connect()
            }

            val code = connection.responseCode
            if (code !in 200..299) {
                throw IllegalStateException("HTTP $code при загрузке $name")
            }

            val reportedLength = connection.contentLengthLong
            var count = 0L
            BufferedInputStream(connection.inputStream).use { input ->
                BufferedOutputStream(FileOutputStream(partial, false)).use { output ->
                    val buffer = ByteArray(256 * 1024)
                    while (true) {
                        if (cancelDownload || Thread.currentThread().isInterrupted) {
                            throw InterruptedException("Загрузка отменена")
                        }
                        val read = input.read(buffer)
                        if (read < 0) break
                        output.write(buffer, 0, read)
                        count += read
                        onProgress(
                            DownloadState(
                                name,
                                count,
                                if (reportedLength > 0) reportedLength else expectedSize
                            )
                        )
                    }
                }
            }

            if (count != expectedSize) {
                throw IllegalStateException(
                    "Размер $name не совпадает: $count из $expectedSize байт"
                )
            }
            if (target.exists()) target.delete()
            if (!partial.renameTo(target)) {
                throw IllegalStateException("Не удалось сохранить $name")
            }
        } catch (e: Exception) {
            partial.delete()
            throw e
        } finally {
            connection?.disconnect()
        }
    }

    /**
     * Loads the already downloaded pair into native Qwen runtime.
     * Call from a background thread.
     */
    @Throws(Exception::class)
    fun loadModel(): Boolean {
        if (!isModelDownloaded()) {
            throw IllegalStateException("Сначала скачай оба файла модели Qwen")
        }
        engine?.close()
        val created = QwenEngine()
        if (!created.isAvailable) {
            created.close()
            throw IllegalStateException(
                "В этой сборке нет native-библиотеки Qwen. Для полной версии запусти GitHub Actions."
            )
        }
        return try {
            val loaded = created.loadModels(modelDirectory.absolutePath, null)
            if (loaded) {
                engine = created
                true
            } else {
                val error = created.getLastError() ?: "Неизвестная ошибка загрузки модели"
                created.close()
                throw IllegalStateException(error)
            }
        } catch (e: Exception) {
            created.close()
            throw e
        }
    }

    /**
     * Synthesis returns raw Qwen audio. No LILL post-processing is applied.
     * languageId: Russian=2069, English=2050, French=2061.
     */
    @Throws(Exception::class)
    fun synthesize(
        text: String,
        languageId: Int = 2069,
        speaker: String? = null,
        maxAudioTokens: Int = 512
    ): Audio {
        require(text.isNotBlank()) { "Пустой текст" }
        val active = engine ?: throw IllegalStateException("Модель Qwen не загружена")
        val result = active.synthesize(
            text = text,
            params = QwenEngine.NativeParams(
                languageId = languageId,
                speaker = speaker,
                maxAudioTokens = maxAudioTokens
            )
        )
        if (!result.success) {
            throw IllegalStateException(
                result.errorMsg ?: active.getLastError() ?: "Ошибка синтеза Qwen"
            )
        }
        val samples = result.audio
            ?: throw IllegalStateException("Qwen вернул пустое аудио")
        if (samples.isEmpty() || result.sampleRate <= 0) {
            throw IllegalStateException("Qwen вернул некорректный аудиопоток")
        }
        return Audio(
            samples = samples,
            sampleRate = result.sampleRate,
            durationMs = samples.size * 1000L / result.sampleRate
        )
    }

    /** Writes raw Qwen float samples as mono PCM16 WAV. */
    fun writeWav(audio: Audio, destination: File) {
        val pcm = ByteArray(audio.samples.size * 2)
        val buffer = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN)
        audio.samples.forEach { sample ->
            val clipped = sample.coerceIn(-1f, 1f)
            val value = (clipped * 32767f).roundToInt()
                .coerceIn(-32768, 32767)
            buffer.putShort(value.toShort())
        }

        val dataSize = pcm.size
        destination.parentFile?.mkdirs()
        BufferedOutputStream(FileOutputStream(destination)).use { out ->
            out.write("RIFF".toByteArray(Charsets.US_ASCII))
            writeIntLE(out, 36 + dataSize)
            out.write("WAVE".toByteArray(Charsets.US_ASCII))
            out.write("fmt ".toByteArray(Charsets.US_ASCII))
            writeIntLE(out, 16)
            writeShortLE(out, 1)
            writeShortLE(out, 1)
            writeIntLE(out, audio.sampleRate)
            writeIntLE(out, audio.sampleRate * 2)
            writeShortLE(out, 2)
            writeShortLE(out, 16)
            out.write("data".toByteArray(Charsets.US_ASCII))
            writeIntLE(out, dataSize)
            out.write(pcm)
        }
    }

    fun deleteModel() {
        engine?.close()
        engine = null
        modelDirectory.deleteRecursively()
    }

    override fun close() {
        engine?.close()
        engine = null
    }

    private fun writeIntLE(out: java.io.OutputStream, value: Int) {
        out.write(value and 0xff)
        out.write((value ushr 8) and 0xff)
        out.write((value ushr 16) and 0xff)
        out.write((value ushr 24) and 0xff)
    }

    private fun writeShortLE(out: java.io.OutputStream, value: Int) {
        out.write(value and 0xff)
        out.write((value ushr 8) and 0xff)
    }
}
