package com.example.lillvoice.newproject.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.media.audiofx.DynamicsProcessing
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper

/**
 * LILL WAV PLAYER
 *
 * Отдельный проигрыватель WAV-файлов.
 * Не вмешивается в существующий TTS.
 */
class LillWavPlayer(
    context: Context,
    private val listener: Listener? = null
) {

    interface Listener {
        fun onPrepared(durationMs: Int) {}
        fun onProgress(positionMs: Int, durationMs: Int) {}
        fun onCompleted() {}
        fun onError(message: String) {}
        fun onPlaybackStateChanged(isPlaying: Boolean) {}
    }

    companion object {
        const val EQUALIZER_BANDS = 10

        val EQUALIZER_FREQUENCIES = floatArrayOf(
            62f,
            125f,
            250f,
            500f,
            1000f,
            2000f,
            4000f,
            8000f,
            12000f,
            20000f
        )

        const val MIN_EQ_GAIN = -12f
        const val MAX_EQ_GAIN = 12f
    }

    private val appContext = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())

    private var mediaPlayer: MediaPlayer? = null

    private var prepared = false
    private var autoPlay = false
    private var released = false

    private var playbackSpeed = 1f
    private var playbackPitch = 1f
    private var volume = 1f

    // Эквалайзер
    private var dynamicsProcessing: DynamicsProcessing? = null
    private var equalizerEnabled = false

    private val equalizerLevels = FloatArray(EQUALIZER_BANDS) { 0f }

    private var preamp = 0f
    private var equalizerSessionId = 0
    private var equalizerError: String? = null

    private val progressRunnable = object : Runnable {
        override fun run() {
            val player = mediaPlayer

            if (player != null && prepared && !released) {
                try {
                    if (player.isPlaying) {
                        listener?.onProgress(
                            player.currentPosition,
                            player.duration
                        )
                        handler.postDelayed(this, 250L)
                    }
                } catch (_: IllegalStateException) {
                }
            }
        }
    }

    fun load(uri: Uri, playWhenReady: Boolean = false) {
        if (released) return

        releaseCurrentPlayer()

        prepared = false
        autoPlay = playWhenReady

        try {
            val player = MediaPlayer()
            mediaPlayer = player

            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )

            player.setDataSource(appContext, uri)

            player.setOnPreparedListener { preparedPlayer ->
                if (released || mediaPlayer !== preparedPlayer) {
                    return@setOnPreparedListener
                }

                prepared = true

                applyPlaybackParams()
                preparedPlayer.setVolume(volume, volume)

                initializeEqualizer(preparedPlayer.audioSessionId)

                listener?.onPrepared(preparedPlayer.duration)

                if (autoPlay) {
                    play()
                }
            }

            player.setOnCompletionListener {
                handler.removeCallbacks(progressRunnable)
                listener?.onPlaybackStateChanged(false)
                listener?.onCompleted()
            }

            player.setOnErrorListener { _, what, extra ->
                handler.removeCallbacks(progressRunnable)
                prepared = false
                listener?.onPlaybackStateChanged(false)

                listener?.onError(
                    "Ошибка воспроизведения: $what / $extra"
                )
                true
            }

            player.prepareAsync()

        } catch (exception: Exception) {
            releaseCurrentPlayer()

            listener?.onError(
                exception.message ?: "Не удалось открыть WAV-файл"
            )
        }
    }

    /**
     * Создание десятиполосного эквалайзера.
     */
    private fun initializeEqualizer(audioSessionId: Int) {
        releaseEqualizer()

        equalizerSessionId = audioSessionId
        equalizerError = null

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            equalizerError = "Требуется Android 9 или новее"
            return
        }

        try {
            /*
             * ВАЖНО:
             * Внутренний блок EQ создаётся включённым.
             * Общим включением управляет effect.enabled.
             *
             * Раньше здесь использовалось equalizerEnabled.
             * При первоначальном false внутренний EQ мог
             * оставаться выключенным даже после включения эффекта.
             */
            val eq = DynamicsProcessing.Eq(
                true,
                true,
                EQUALIZER_BANDS
            )

            for (index in 0 until EQUALIZER_BANDS) {
                eq.setBand(
                    index,
                    DynamicsProcessing.EqBand(
                        true,
                        EQUALIZER_FREQUENCIES[index],
                        equalizerLevels[index]
                    )
                )
            }

            val config = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                2,
                true,
                EQUALIZER_BANDS,
                false,
                0,
                false,
                0,
                false
            )
                .setPreEqAllChannelsTo(eq)
                .setInputGainAllChannelsTo(preamp)
                .build()

            val effect = DynamicsProcessing(
                0,
                audioSessionId,
                config
            )

            dynamicsProcessing = effect
            effect.enabled = equalizerEnabled

            if (!effect.hasControl()) {
                equalizerError =
                    "Эффект создан, но управление им не получено"
            }

        } catch (exception: Exception) {
            dynamicsProcessing = null

            equalizerError =
                exception.message ?: exception.javaClass.simpleName

            listener?.onError(
                "Не удалось создать эквалайзер: $equalizerError"
            )
        }
    }

    /**
     * Диагностика эквалайзера.
     * Возвращает текстовое состояние эффекта.
     */
    fun getEqualizerDiagnostics(): String {
        val player = mediaPlayer
        val effect = dynamicsProcessing

        val lines = mutableListOf<String>()

        lines.add("Android API: ${Build.VERSION.SDK_INT}")
        lines.add("MediaPlayer готов: $prepared")
        lines.add("Воспроизведение: ${isPlaying()}")
        lines.add("AudioSession MediaPlayer: ${player?.audioSessionId ?: 0}")
        lines.add("AudioSession EQ: $equalizerSessionId")
        lines.add("EQ запрошен включённым: $equalizerEnabled")
        lines.add("EQ-эффект создан: ${effect != null}")

        if (effect != null) {
            try {
                lines.add("Эффект включён: ${effect.enabled}")
                lines.add("Управление получено: ${effect.hasControl()}")
                lines.add("ID эффекта: ${effect.id}")
            } catch (exception: Exception) {
                lines.add(
                    "Ошибка чтения состояния: " +
                        (exception.message ?: "неизвестная ошибка")
                )
            }
        }

        lines.add("Предусиление: $preamp dB")
        lines.add("Уровни полос: ${equalizerLevels.joinToString()}")

        if (equalizerError != null) {
            lines.add("Ошибка EQ: $equalizerError")
        }

        return lines.joinToString("\n")
    }

    fun setEqualizerEnabled(enabled: Boolean) {
        equalizerEnabled = enabled

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            equalizerError = "Требуется Android 9 или новее"
            return
        }

        try {
            val effect = dynamicsProcessing

            if (effect == null) {
                equalizerError = "Эквалайзер ещё не создан"
                return
            }

            effect.enabled = enabled
            equalizerError = null

        } catch (exception: Exception) {
            equalizerError =
                exception.message ?: exception.javaClass.simpleName
        }
    }

    fun isEqualizerEnabled(): Boolean {
        return equalizerEnabled
    }

    fun setEqualizerBandLevel(index: Int, gainDb: Float) {
        if (index !in 0 until EQUALIZER_BANDS) return

        val safeGain = gainDb.coerceIn(MIN_EQ_GAIN, MAX_EQ_GAIN)
        equalizerLevels[index] = safeGain

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return

        try {
            val effect = dynamicsProcessing ?: return

            val band = DynamicsProcessing.EqBand(
                true,
                EQUALIZER_FREQUENCIES[index],
                safeGain
            )

            effect.setPreEqBandAllChannelsTo(index, band)

        } catch (exception: Exception) {
            equalizerError =
                exception.message ?: exception.javaClass.simpleName
        }
    }

    fun getEqualizerBandLevel(index: Int): Float {
        if (index !in 0 until EQUALIZER_BANDS) return 0f
        return equalizerLevels[index]
    }

    fun getEqualizerLevels(): FloatArray {
        return equalizerLevels.copyOf()
    }

    fun setPreamp(gainDb: Float) {
        preamp = gainDb.coerceIn(-12f, 12f)

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return

        try {
            dynamicsProcessing?.setInputGainAllChannelsTo(preamp)
        } catch (exception: Exception) {
            equalizerError =
                exception.message ?: exception.javaClass.simpleName
        }
    }

    fun getPreamp(): Float {
        return preamp
    }

    fun resetEqualizer() {
        for (index in 0 until EQUALIZER_BANDS) {
            setEqualizerBandLevel(index, 0f)
        }

        setPreamp(0f)
    }

    fun play() {
        if (released) return

        val player = mediaPlayer ?: return

        if (!prepared) {
            autoPlay = true
            return
        }

        try {
            applyPlaybackParams()
            player.setVolume(volume, volume)
            player.start()

            handler.removeCallbacks(progressRunnable)
            handler.post(progressRunnable)

            listener?.onPlaybackStateChanged(true)

        } catch (exception: Exception) {
            listener?.onError(
                exception.message ?: "Не удалось начать воспроизведение"
            )
        }
    }

    fun pause() {
        val player = mediaPlayer ?: return
        if (!prepared || released) return

        try {
            if (player.isPlaying) {
                player.pause()
            }

            handler.removeCallbacks(progressRunnable)
            listener?.onPlaybackStateChanged(false)

        } catch (_: IllegalStateException) {
        }
    }

    fun stop() {
        val player = mediaPlayer ?: return
        if (!prepared || released) return

        try {
            if (player.isPlaying) {
                player.pause()
            }

            player.seekTo(0)
            handler.removeCallbacks(progressRunnable)

            listener?.onProgress(0, player.duration)
            listener?.onPlaybackStateChanged(false)

        } catch (_: IllegalStateException) {
        }
    }

    fun seekTo(positionMs: Int) {
        val player = mediaPlayer ?: return
        if (!prepared || released) return

        try {
            val safePosition = positionMs.coerceIn(0, player.duration)
            player.seekTo(safePosition)

            listener?.onProgress(safePosition, player.duration)

        } catch (_: IllegalStateException) {
        }
    }

    fun setSpeed(speed: Float) {
        playbackSpeed = speed.coerceIn(0.5f, 2f)

        if (prepared && !released) {
            applyPlaybackParams()
        }
    }

    fun setPitch(pitch: Float) {
        playbackPitch = pitch.coerceIn(0.5f, 2f)

        if (prepared && !released) {
            applyPlaybackParams()
        }
    }

    fun setVolume(value: Float) {
        volume = value.coerceIn(0f, 1f)

        try {
            mediaPlayer?.setVolume(volume, volume)
        } catch (_: IllegalStateException) {
        }
    }

    private fun applyPlaybackParams() {
        val player = mediaPlayer ?: return
        if (!prepared || released) return

        try {
            val params = PlaybackParams()
                .setSpeed(playbackSpeed)
                .setPitch(playbackPitch)

            player.playbackParams = params

        } catch (exception: Exception) {
            listener?.onError(
                exception.message
                    ?: "Не удалось применить параметры воспроизведения"
            )
        }
    }

    fun getCurrentPosition(): Int {
        if (!prepared || released) return 0

        return try {
            mediaPlayer?.currentPosition ?: 0
        } catch (_: IllegalStateException) {
            0
        }
    }

    fun getDuration(): Int {
        if (!prepared || released) return 0

        return try {
            mediaPlayer?.duration ?: 0
        } catch (_: IllegalStateException) {
            0
        }
    }

    fun isPlaying(): Boolean {
        if (!prepared || released) return false

        return try {
            mediaPlayer?.isPlaying == true
        } catch (_: IllegalStateException) {
            false
        }
    }

    fun isPrepared(): Boolean {
        return prepared && !released
    }

    private fun releaseEqualizer() {
        try {
            dynamicsProcessing?.release()
        } catch (_: Exception) {
        }

        dynamicsProcessing = null
        equalizerSessionId = 0
    }

    private fun releaseCurrentPlayer() {
        handler.removeCallbacks(progressRunnable)
        releaseEqualizer()

        val player = mediaPlayer

        mediaPlayer = null
        prepared = false

        try {
            player?.release()
        } catch (_: Exception) {
        }
    }

    fun release() {
        if (released) return

        released = true
        autoPlay = false

        releaseCurrentPlayer()
    }
}
