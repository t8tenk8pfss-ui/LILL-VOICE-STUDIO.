package com.example.lillvoice.newproject.voice

class LillSpeechCore {

    private val textBrain = LillTextBrain()
    private val emotionEngine = LillEmotionEngine()
    private val speechPlanner = LillSpeechPlanner()
    private val prosodyEngine = LillProsodyEngine()
    private val voiceProcessor = LillVoiceProcessor()

    private val voiceProfile = LillVoiceProfile.default()

    data class PreparedSegment(
        val text: String,
        val emotion: LillEmotionEngine.Emotion,
        val intensity: Float,
        val confidence: Float,
        val speed: Float,
        val pitch: Float,
        val pauseAfterMs: Long,
        val emphasis: Boolean,
        val audioSettings: LillVoiceProcessor.AudioSettings,
        val prosody: LillProsodyEngine.ProsodyPlan
    )

    data class PreparedSpeech(
        val originalText: String,
        val segments: List<PreparedSegment>,
        val totalCharacters: Int,
        val totalWords: Int,
        val estimatedDurationMs: Long
    )

    fun prepareSpeech(text: String): PreparedSpeech {

        val analysis = textBrain.analyze(text)
        val plan = speechPlanner.createPlan(text)

        val preparedSegments = plan.segments.map { segment ->

            val emotionResult = emotionEngine.analyze(
                segment.text
            )

            val voiceSettings = voiceProfile.settingsFor(
                emotion = emotionResult.emotion,
                intensity = emotionResult.intensity
            )

            val prosody = prosodyEngine.createPlan(
                text = segment.text,
                emotion = emotionResult.emotion,
                intensity = emotionResult.intensity,
                baseSpeed = voiceProfile.baseSpeed,
                basePitch = voiceSettings.pitch,
                expressiveness = voiceProfile.expressiveness
            )

            val audioSettings = voiceProcessor.settingsFrom(
                profile = voiceProfile,
                emotion = emotionResult.emotion,
                intensity = emotionResult.intensity
            )

            val finalSpeed = prosody.speed.coerceIn(
                voiceProfile.minSpeed,
                voiceProfile.maxSpeed
            )

            val finalPitch = voiceSettings.pitch.coerceIn(
                voiceProfile.minPitch,
                voiceProfile.maxPitch
            )

            PreparedSegment(
                text = segment.text,
                emotion = emotionResult.emotion,
                intensity = emotionResult.intensity,
                confidence = emotionResult.confidence,
                speed = finalSpeed,
                pitch = finalPitch,
                pauseAfterMs = prosody.pauseAfterMs,
                emphasis = prosody.emphasis >= 0.6f,
                audioSettings = audioSettings,
                prosody = prosody
            )
        }

        val estimatedDuration = preparedSegments.sumOf { segment ->
            val speechTime = (
                segment.text.length * 65.0 /
                    segment.speed.coerceAtLeast(0.5f)
            ).toLong()

            speechTime + segment.pauseAfterMs
        }

        return PreparedSpeech(
            originalText = text,
            segments = preparedSegments,
            totalCharacters = analysis.totalCharacters,
            totalWords = analysis.totalWords,
            estimatedDurationMs = estimatedDuration
        )
    }

    fun getVoiceProfile(): LillVoiceProfile {
        return voiceProfile
    }

    fun processAudio(
        input: FloatArray,
        settings: LillVoiceProcessor.AudioSettings
    ): FloatArray {
        return voiceProcessor.process(
            input = input,
            settings = settings
        )
    }

    fun convertAudioToPcm16(
        input: FloatArray
    ): ShortArray {
        return voiceProcessor.toPcm16(input)
    }
}
