package com.example.lillvoice.newproject.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import com.example.lillvoice.newproject.MainActivity

class LillWavPlaybackService : Service() {

    companion object {
        const val ACTION_LOAD = "com.example.lillvoice.LOAD"
        const val ACTION_PLAY = "com.example.lillvoice.PLAY"
        const val ACTION_PAUSE = "com.example.lillvoice.PAUSE"
        const val ACTION_STOP = "com.example.lillvoice.STOP"
        const val ACTION_TOGGLE = "com.example.lillvoice.TOGGLE"

        const val EXTRA_URI = "wav_uri"
        const val EXTRA_NAME = "wav_name"

        private const val CHANNEL_ID = "lill_wav_playback"
        private const val NOTIFICATION_ID = 7301
    }

    interface UiListener {
        fun onPrepared(durationMs: Int)
        fun onProgress(positionMs: Int, durationMs: Int)
        fun onCompleted()
        fun onError(message: String)
        fun onPlaybackStateChanged(isPlaying: Boolean)
    }

    inner class LocalBinder : Binder() {
        fun getService(): LillWavPlaybackService = this@LillWavPlaybackService
    }

    private val binder = LocalBinder()

    private lateinit var player: LillWavPlayer
    private lateinit var mediaSession: MediaSession
    private lateinit var equalizerSettings: LillEqualizerSettings

    private var uiListener: UiListener? = null
    private var fileName = "WAV"
    private var foregroundStarted = false

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()

        equalizerSettings = LillEqualizerSettings(
            applicationContext
        )

        player = LillWavPlayer(
            applicationContext,
            object : LillWavPlayer.Listener {

                override fun onPrepared(durationMs: Int) {
                    mediaSession.setMetadata(
                        MediaMetadata.Builder()
                            .putString(
                                MediaMetadata.METADATA_KEY_TITLE,
                                fileName
                            )
                            .putLong(
                                MediaMetadata.METADATA_KEY_DURATION,
                                durationMs.toLong()
                            )
                            .build()
                    )

                    updatePlaybackState(PlaybackState.STATE_PAUSED)
                    uiListener?.onPrepared(durationMs)
                    updateNotification()
                }

                override fun onProgress(
                    positionMs: Int,
                    durationMs: Int
                ) {
                    uiListener?.onProgress(positionMs, durationMs)
                    updatePlaybackState()
                }

                override fun onCompleted() {
                    updatePlaybackState(PlaybackState.STATE_STOPPED)
                    uiListener?.onCompleted()
                    updateNotification()
                }

                override fun onError(message: String) {
                    updatePlaybackState(PlaybackState.STATE_ERROR)
                    uiListener?.onError(message)
                    updateNotification()
                }

                override fun onPlaybackStateChanged(isPlaying: Boolean) {
                    updatePlaybackState()
                    uiListener?.onPlaybackStateChanged(isPlaying)
                    updateNotification()
                }
            }
        )

        restoreEqualizerSettings()

        mediaSession = MediaSession(
            this,
            "LILL_WAV_SESSION"
        ).apply {

            setFlags(
                MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or
                    MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS
            )

            setCallback(
                object : MediaSession.Callback() {

                    override fun onPlay() {
                        play()
                    }

                    override fun onPause() {
                        pause()
                    }

                    override fun onStop() {
                        stopPlayback()
                    }

                    override fun onSeekTo(pos: Long) {
                        seekTo(pos.toInt())
                    }

                    override fun onCustomAction(
                        action: String,
                        extras: Bundle?
                    ) {
                        when (action) {
                            ACTION_STOP -> stopPlayback()
                            ACTION_TOGGLE -> togglePlayback()
                        }
                    }
                }
            )

            isActive = true
        }

        updatePlaybackState(PlaybackState.STATE_PAUSED)
    }

    override fun onBind(intent: Intent?): IBinder {
        return binder
    }

    fun setUiListener(listener: UiListener?) {
        uiListener = listener
    }

    /**
     * Восстановление сохранённых настроек эквалайзера.
     */
    private fun restoreEqualizerSettings() {

        player.setEqualizerEnabled(
            equalizerSettings.isEnabled()
        )

        val levels = equalizerSettings.getAllBandLevels()

        for (index in levels.indices) {
            player.setEqualizerBandLevel(
                index,
                levels[index]
            )
        }

        player.setPreamp(
            equalizerSettings.getPreamp()
        )
    }

    /**
     * Открытие всплывающего окна эквалайзера.
     *
     * Context должен принадлежать Activity.
     */
    fun showEqualizer(context: Context) {

        if (!::player.isInitialized ||
            !::equalizerSettings.isInitialized
        ) {
            return
        }

        LillEqualizerDialog(
            context,
            player,
            equalizerSettings
        ).show()
    }

    /**
     * Доступ к сохранённым настройкам эквалайзера.
     */
    fun getEqualizerSettings(): LillEqualizerSettings {
        return equalizerSettings
    }

    /**
     * Включение или отключение эквалайзера.
     */
    fun setEqualizerEnabled(enabled: Boolean) {

        equalizerSettings.setEnabled(enabled)
        player.setEqualizerEnabled(enabled)
    }

    fun isEqualizerEnabled(): Boolean {
        return equalizerSettings.isEnabled()
    }

    /**
     * Установка уровня полосы.
     */
    fun setEqualizerBandLevel(
        index: Int,
        gainDb: Float
    ) {

        equalizerSettings.setBandLevel(
            index,
            gainDb
        )

        player.setEqualizerBandLevel(
            index,
            gainDb
        )
    }

    /**
     * Установка всех полос.
     */
    fun setEqualizerLevels(levels: FloatArray) {

        equalizerSettings.setAllBandLevels(levels)

        for (index in 0 until LillEqualizerSettings.BAND_COUNT) {

            player.setEqualizerBandLevel(
                index,
                equalizerSettings.getBandLevel(index)
            )
        }
    }

    /**
     * Предусиление.
     */
    fun setEqualizerPreamp(value: Float) {

        equalizerSettings.setPreamp(value)
        player.setPreamp(value)
    }

    /**
     * Применение пресета.
     */
    fun applyEqualizerPreset(name: String): Boolean {

        if (!equalizerSettings.applyPreset(name)) {
            return false
        }

        restoreEqualizerSettings()

        return true
    }

    /**
     * Сброс настроек эквалайзера.
     */
    fun resetEqualizer() {

        equalizerSettings.reset()
        restoreEqualizerSettings()
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        when (intent?.action) {

            ACTION_LOAD -> {
                startForegroundNotification()

                val uri = intent.data
                    ?: intent.getParcelableExtra(EXTRA_URI) as? Uri

                if (uri != null) {
                    fileName = intent.getStringExtra(EXTRA_NAME)
                        ?: "WAV"

                    player.load(uri, false)

                    updatePlaybackState(
                        PlaybackState.STATE_PAUSED
                    )

                    updateNotification()
                }
            }

            ACTION_PLAY -> play()

            ACTION_PAUSE -> pause()

            ACTION_TOGGLE -> togglePlayback()

            ACTION_STOP -> stopPlayback()
        }

        return START_NOT_STICKY
    }

    fun play() {
        startForegroundNotification()
        player.play()
        updatePlaybackState()
        updateNotification()
    }

    fun pause() {
        player.pause()
        updatePlaybackState()
        updateNotification()
    }

    private fun togglePlayback() {
        if (player.isPlaying()) {
            pause()
        } else {
            play()
        }
    }

    fun stop() {
        stopPlayback()
    }

    private fun stopPlayback() {
        player.stop()

        updatePlaybackState(
            PlaybackState.STATE_STOPPED
        )

        if (foregroundStarted) {

            if (Build.VERSION.SDK_INT >= 24) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }

            foregroundStarted = false
        }
    }

    fun seekTo(positionMs: Int) {
        player.seekTo(positionMs)
        updatePlaybackState()
    }

    fun setSpeed(speed: Float) {
        player.setSpeed(speed)
        updatePlaybackState()
    }

    fun setPitch(pitch: Float) {
        player.setPitch(pitch)
    }

    fun isPlaying(): Boolean {
        return player.isPlaying()
    }

    private fun startForegroundNotification() {

        if (foregroundStarted) {
            updateNotification()
            return
        }

        val notification = buildNotification()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(
                NOTIFICATION_ID,
                notification
            )
        }

        foregroundStarted = true
    }

    private fun createNotificationChannel() {

        if (Build.VERSION.SDK_INT < 26) return

        val channel = NotificationChannel(
            CHANNEL_ID,
            "LILL WAV PLAYER",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Управление воспроизведением WAV"
            setShowBadge(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }

        val manager = getSystemService(
            NotificationManager::class.java
        )

        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {

        val playing = player.isPlaying()

        val playPauseAction = Notification.Action.Builder(
            if (playing) {
                android.R.drawable.ic_media_pause
            } else {
                android.R.drawable.ic_media_play
            },
            if (playing) "Пауза" else "Продолжить",
            servicePendingIntent(ACTION_TOGGLE, 7302)
        ).build()

        val stopAction = Notification.Action.Builder(
            android.R.drawable.ic_menu_close_clear_cancel,
            "Стоп",
            servicePendingIntent(ACTION_STOP, 7304)
        ).build()

        val contentIntent = PendingIntent.getActivity(
            this,
            7305,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or
                PendingIntent.FLAG_IMMUTABLE
        )

        mediaSession.setSessionActivity(contentIntent)

        val mediaStyle = Notification.MediaStyle().apply {
            setMediaSession(mediaSession.sessionToken)
            setShowActionsInCompactView(0, 1)
        }

        return Notification.Builder(
            this,
            CHANNEL_ID
        )
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(fileName)
            .setContentText(
                if (playing) {
                    "LILL WAV PLAYER · Воспроизведение"
                } else {
                    "LILL WAV PLAYER · Пауза"
                }
            )
            .setContentIntent(contentIntent)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(playPauseAction)
            .addAction(stopAction)
            .setStyle(mediaStyle)
            .build()
    }

    private fun servicePendingIntent(
        action: String,
        requestCode: Int
    ): PendingIntent {

        val intent = Intent(
            this,
            LillWavPlaybackService::class.java
        ).setAction(action)

        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun updateNotification() {

        if (!foregroundStarted) return

        val manager = getSystemService(
            NotificationManager::class.java
        )

        manager.notify(
            NOTIFICATION_ID,
            buildNotification()
        )
    }

    private fun updatePlaybackState(
        requestedState: Int? = null
    ) {

        if (!::mediaSession.isInitialized ||
            !::player.isInitialized
        ) {
            return
        }

        val playing = player.isPlaying()

        val state = requestedState ?: if (playing) {
            PlaybackState.STATE_PLAYING
        } else {
            PlaybackState.STATE_PAUSED
        }

        val actions =
            PlaybackState.ACTION_PLAY or
                PlaybackState.ACTION_PAUSE or
                PlaybackState.ACTION_PLAY_PAUSE or
                PlaybackState.ACTION_STOP or
                PlaybackState.ACTION_SEEK_TO

        val playbackSpeed = if (
            state == PlaybackState.STATE_PLAYING
        ) {
            1f
        } else {
            0f
        }

        val playbackStateBuilder = PlaybackState.Builder()
            .setActions(actions)
            .setState(
                state,
                player.getCurrentPosition().toLong(),
                playbackSpeed
            )
            .addCustomAction(
                PlaybackState.CustomAction.Builder(
                    ACTION_STOP,
                    "Стоп",
                    android.R.drawable.ic_menu_close_clear_cancel
                ).build()
            )

        mediaSession.setPlaybackState(
            playbackStateBuilder.build()
        )
    }

    override fun onDestroy() {

        uiListener = null

        if (::player.isInitialized) {
            player.release()
        }

        if (::mediaSession.isInitialized) {
            mediaSession.isActive = false
            mediaSession.release()
        }

        super.onDestroy()
    }
}
