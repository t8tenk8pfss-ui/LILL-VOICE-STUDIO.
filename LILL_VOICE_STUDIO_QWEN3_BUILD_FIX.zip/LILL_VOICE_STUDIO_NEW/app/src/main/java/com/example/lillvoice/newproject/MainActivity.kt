package com.example.lillvoice.newproject

import android.content.ContentValues
import android.app.ProgressDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.lillvoice.newproject.voice.LillSpeechCore
import com.example.lillvoice.newproject.voice.LillWavProcessor
import com.example.lillvoice.newproject.voice.LillWavUiController
import com.example.lillvoice.newproject.voice.QwenLocalTts
import java.io.File
import java.io.RandomAccessFile
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    companion object {
        private const val HAYAI_ENGINE = "dev.ahmedmohamed.hayaitts"
        private const val ENGINE_PREF = "engine_package"
        private const val QWEN_ENGINE = "local.qwen3.tts"
    }

    private lateinit var tts: TextToSpeech
    private lateinit var wavUiController: LillWavUiController
    private lateinit var qwen: QwenLocalTts
    private var qwenSelected = false
    private var qwenReady = false
    @Volatile private var qwenBusy = false
    private var qwenPlayer: MediaPlayer? = null
    private var qwenAudioFile: File? = null
    private var qwenStartPosition = 0
    private var qwenPlaybackLength = 0
    private var qwenProgressTask: Runnable? = null

    private val speechCore = LillSpeechCore()
    private val wavProcessor = LillWavProcessor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var editText: EditText
    private lateinit var charCount: TextView
    private lateinit var voiceSpinner: Spinner
    private lateinit var speedSeekBar: SeekBar
    private lateinit var pitchSeekBar: SeekBar
    private lateinit var speedValue: TextView
    private lateinit var pitchValue: TextView
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var positionSeekBar: SeekBar
    private lateinit var positionValue: TextView
    private lateinit var playButton: Button
    private lateinit var stopButton: Button
    private lateinit var testButton: Button
    private lateinit var exportButton: Button
    private lateinit var settingsButton: Button
    private lateinit var backgroundImage: ImageView
    private lateinit var backgroundOverlay: View

    private val backgroundPrefs by lazy {
        getSharedPreferences("corvus_background", MODE_PRIVATE)
    }

    private val speechPrefs by lazy {
        getSharedPreferences("corvus_speech", MODE_PRIVATE)
    }

    private data class EngineItem(
        val packageName: String,
        val label: String
    )

    private data class VoiceItem(
        val name: String,
        val voice: Voice
    )

    private data class LanguageItem(
        val code: String,
        val locale: Locale,
        val displayName: String
    )

    private data class SpeechPart(
        val text: String,
        val start: Int,
        val end: Int
    )

    private data class WavInfo(
        val format: ByteArray,
        val dataOffset: Long,
        val dataSize: Long
    )

    private var availableEngines = listOf<EngineItem>()
    private var activeEngine = ""
    private var activeVoiceName = ""

    private var engineInitToken = 0
    private var resumeAfterEngineInit = false
    private var engineResumePosition = 0

    private var voices = listOf<VoiceItem>()
    private var availableLanguages = listOf<LanguageItem>()
    private var selectedLanguageCode = "ru"

    private var ttsReady = false
    private var exporting = false
    private var speaking = false
    private var seeking = false
    private var resumeAfterSeek = false
    private var pitchTestRunning = false
    private var pitchTestIndex = 0

    private var playbackToken = 0
    private var exportToken = 0
    private var sourceText = ""
    private var speechParts = listOf<SpeechPart>()
    private var nextPartIndex = 0
    private var currentPosition = 0
    private var currentPart: SpeechPart? = null
    private var currentUtteranceId: String? = null
    private var lastSelectedVoice = -1
    private var currentPauseAfterMs = 0L
    private var pendingNextPart: Runnable? = null

    private val utteranceParts = mutableMapOf<String, SpeechPart>()
    private val executor = Executors.newSingleThreadExecutor()
    private val tempFiles = mutableListOf<File>()

    private val imagePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )

                    backgroundPrefs.edit()
                        .putString("image_uri", uri.toString())
                        .apply()

                    showBackground(uri)
                    toast("Фоновое изображение установлено")
                } catch (e: Exception) {
                    toast("Не удалось установить изображение")
                }
            }
        }

    private val wavPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null && ::wavUiController.isInitialized) {
                wavUiController.load(uri)
            }
        }

    // ====================================================
    // СОЗДАНИЕ АКТИВНОСТИ
    // ====================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        configureFullscreen()
        setContentView(R.layout.activity_main)

        wavUiController = LillWavUiController(this, wavPicker)
        qwen = QwenLocalTts(this)
        wavUiController.setup()

        editText = findViewById(R.id.editText)
        charCount = findViewById(R.id.charCount)
        voiceSpinner = findViewById(R.id.voiceSpinner)
        speedSeekBar = findViewById(R.id.speedSeekBar)
        pitchSeekBar = findViewById(R.id.pitchSeekBar)
        speedValue = findViewById(R.id.speedValue)
        pitchValue = findViewById(R.id.pitchValue)
        statusText = findViewById(R.id.statusText)
        progressBar = findViewById(R.id.progressBar)
        positionSeekBar = findViewById(R.id.positionSeekBar)
        positionValue = findViewById(R.id.positionValue)
        playButton = findViewById(R.id.playButton)
        stopButton = findViewById(R.id.stopButton)
        testButton = findViewById(R.id.testButton)
        exportButton = findViewById(R.id.exportButton)
        settingsButton = findViewById(R.id.settingsButton)
        backgroundImage = findViewById(R.id.backgroundImage)
        backgroundOverlay = findViewById(R.id.backgroundOverlay)

        restoreBackground()
        updateBackgroundDim(
            backgroundPrefs.getInt("background_dim", 40)
        )

        setupButtons()
        setupTextEditor()
        setupSpeechControls()
        setupPositionControl()

        statusText.text = "Подключение TTS-движка..."
        initializeEngine(null)
    }

    private fun configureFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, true)

        WindowInsetsControllerCompat(
            window,
            window.decorView
        ).apply {
            hide(WindowInsetsCompat.Type.statusBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    // ====================================================
    // ЕДИНОЕ МЕНЮ НАСТРОЕК
    // ====================================================

    private fun showSettingsDialog() {
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(14))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(Color.argb(238, 12, 10, 12))
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.rgb(190, 0, 35))
            }
        }

        val scrollView = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(0, 0, 0, 0)
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val heading = TextView(this).apply {
            text = "CORVUS-S"
            textSize = 22f
            setTextColor(Color.rgb(235, 0, 42))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = android.view.Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "LILL VOICE STUDIO  •  SETTINGS"
            textSize = 10f
            letterSpacing = 0.13f
            setTextColor(Color.LTGRAY)
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(5), 0, dp(14))
        }

        val divider = View(this).apply {
            setBackgroundColor(Color.rgb(180, 0, 30))
        }

        content.addView(
            heading,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        content.addView(subtitle)

        content.addView(
            divider,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(1)
            ).apply {
                bottomMargin = dp(14)
            }
        )

        val dialog = AlertDialog.Builder(this)
            .setView(scrollView)
            .create()

        fun addMenuButton(
            icon: String,
            title: String,
            description: String,
            action: () -> Unit
        ) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(11), dp(12), dp(11))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    setColor(Color.argb(85, 100, 0, 20))
                    cornerRadius = dp(12).toFloat()
                    setStroke(
                        dp(1),
                        Color.argb(150, 190, 0, 35)
                    )
                }
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    dialog.dismiss()
                    action()
                }
            }

            val iconView = TextView(this).apply {
                text = icon
                textSize = 24f
                setTextColor(Color.rgb(255, 45, 70))
                gravity = android.view.Gravity.CENTER
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }

            item.addView(
                iconView,
                LinearLayout.LayoutParams(dp(42), dp(42))
            )

            val labels = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), 0, 0, 0)
            }

            val titleView = TextView(this).apply {
                text = title
                textSize = 13f
                setTextColor(Color.WHITE)
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }

            val descriptionView = TextView(this).apply {
                text = description
                textSize = 10f
                setTextColor(Color.LTGRAY)
                setPadding(0, dp(3), 0, 0)
            }

            labels.addView(titleView)
            labels.addView(descriptionView)

            item.addView(
                labels,
                LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
            )

            content.addView(
                item,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(9)
                }
            )
        }

        addMenuButton(
            "▧",
            "ФОНОВОЕ ИЗОБРАЖЕНИЕ",
            "Выбрать изображение из галереи"
        ) {
            imagePicker.launch(arrayOf("image/*"))
        }

        addMenuButton(
            "◐",
            "ПРОЗРАЧНОСТЬ И ЗАТЕМНЕНИЕ",
            "Настроить видимость фонового изображения"
        ) {
            showTransparencyDialog()
        }

        addMenuButton(
            "♫",
            "TTS-ДВИЖОК",
            "Выбрать систему синтеза речи"
        ) {
            showEngineDialog()
        }

        addMenuButton(
            "Q",
            "МОДЕЛЬ QWEN3-TTS",
            "Скачать, загрузить или удалить локальную модель"
        ) {
            showQwenModelDialog()
        }

        addMenuButton(
            "◉",
            "ЯЗЫК И ГОЛОС",
            "Настроить язык и голос озвучивания"
        ) {
            showLanguageDialog()
        }

        addMenuButton(
            "↺",
            "СБРОСИТЬ ФОН",
            "Удалить изображение и вернуть затемнение по умолчанию"
        ) {
            resetBackground()
        }

        val closeButton = Button(this).apply {
            text = "ЗАКРЫТЬ"
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(Color.argb(45, 190, 0, 35))
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), Color.rgb(190, 0, 35))
            }
            setOnClickListener {
                dialog.dismiss()
            }
        }

        content.addView(
            closeButton,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44)
            ).apply {
                topMargin = dp(4)
            }
        )

        scrollView.addView(content)

        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(
                android.R.color.transparent
            )
            dialog.window?.setDimAmount(0.72f)
        }

        dialog.show()

        dialog.window?.setBackgroundDrawableResource(
            android.R.color.transparent
        )
        dialog.window?.setDimAmount(0.72f)
    }

    // ====================================================
    // НАСТРОЙКА ПРОЗРАЧНОСТИ ФОНА
    // ====================================================

    private fun showTransparencyDialog() {
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        val savedDim = backgroundPrefs
            .getInt("background_dim", 40)
            .coerceIn(0, 85)

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(12))

            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(Color.argb(238, 12, 10, 12))
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.rgb(180, 0, 30))
            }
        }

        val description = TextView(this).apply {
            text = "ЗАТЕМНЕНИЕ ИЗОБРАЖЕНИЯ"
            setTextColor(Color.WHITE)
            textSize = 13f
        }

        val percentage = TextView(this).apply {
            text = "$savedDim%"
            setTextColor(Color.rgb(255, 45, 65))
            textSize = 20f
            setPadding(0, dp(10), 0, dp(4))
        }

        val dimSeekBar = SeekBar(this).apply {
            max = 85
            progress = savedDim
            progressTintList =
                android.content.res.ColorStateList.valueOf(
                    Color.rgb(224, 0, 32)
                )
            thumbTintList =
                android.content.res.ColorStateList.valueOf(
                    Color.rgb(224, 0, 32)
                )
        }

        val hint = TextView(this).apply {
            text = "0% — изображение без затемнения. 85% — максимально тёмный фон."
            setTextColor(Color.LTGRAY)
            textSize = 11f
            setPadding(0, dp(8), 0, 0)
        }

        container.addView(description)
        container.addView(percentage)

        container.addView(
            dimSeekBar,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44)
            )
        )

        container.addView(hint)

        val dialog = AlertDialog.Builder(this)
            .setTitle("ПРОЗРАЧНОСТЬ ФОНА")
            .setView(container)
            .setPositiveButton("ГОТОВО", null)
            .setNeutralButton("СБРОСИТЬ", null)
            .setNegativeButton("НАЗАД", null)
            .create()

        dimSeekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    percentage.text = "$progress%"
                    updateBackgroundDim(progress)

                    if (fromUser) {
                        backgroundPrefs.edit()
                            .putInt("background_dim", progress)
                            .apply()
                    }
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            }
        )

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).apply {
                setTextColor(Color.rgb(255, 55, 75))
                setOnClickListener {
                    dialog.dismiss()
                }
            }

            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).apply {
                setTextColor(Color.rgb(255, 55, 75))
                setOnClickListener {
                    dimSeekBar.progress = 40
                    updateBackgroundDim(40)

                    backgroundPrefs.edit()
                        .putInt("background_dim", 40)
                        .apply()
                }
            }

            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(Color.LTGRAY)

            dialog.window?.setBackgroundDrawable(
                GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    setColor(Color.argb(238, 12, 10, 12))
                    cornerRadius = dp(14).toFloat()
                    setStroke(dp(1), Color.rgb(180, 0, 30))
                }
            )
        }

        dialog.show()
    }

    private fun updateBackgroundDim(progress: Int) {
        backgroundOverlay.alpha =
            progress.coerceIn(0, 85) / 100f
    }

    private fun restoreBackground() {
        val savedUri = backgroundPrefs.getString("image_uri", null)

        if (savedUri != null) {
            showBackground(Uri.parse(savedUri))
        }
    }

    private fun showBackground(uri: Uri) {
        try {
            backgroundImage.setImageURI(uri)
            backgroundImage.visibility = View.VISIBLE
        } catch (e: Exception) {
            backgroundImage.visibility = View.GONE
            backgroundPrefs.edit()
                .remove("image_uri")
                .apply()

            toast("Не удалось загрузить фоновое изображение")
        }
    }

    private fun resetBackground() {
        backgroundPrefs.edit()
            .remove("image_uri")
            .putInt("background_dim", 40)
            .apply()

        backgroundImage.setImageDrawable(null)
        backgroundImage.visibility = View.GONE
        updateBackgroundDim(40)

        toast("Фон сброшен")
    }

    // ====================================================
    // TTS-ДВИЖКИ
    // ====================================================

    private fun discoverEngines(): List<EngineItem> {
        if (!::tts.isInitialized) return emptyList()

        return try {
            tts.engines
                .map {
                    EngineItem(
                        packageName = it.name,
                        label = it.label?.toString()
                            ?.takeIf { label -> label.isNotBlank() }
                            ?: it.name
                    )
                }
                .distinctBy { it.packageName }
                .sortedBy {
                    it.label.lowercase(Locale.getDefault())
                }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun engineLabel(packageName: String): String {
        return availableEngines.firstOrNull {
            it.packageName == packageName
        }?.label ?: when (packageName) {
            QWEN_ENGINE -> "Qwen3-TTS (локально)"
            HAYAI_ENGINE -> "HayaiTTS"
            "" -> "Системный TTS"
            else -> packageName
        }
    }

    private fun showEngineDialog() {
        if (exporting) {
            toast("Дождись завершения экспорта WAV")
            return
        }

        availableEngines = discoverEngines() + EngineItem(
            QWEN_ENGINE,
            "Qwen3-TTS (локальная модель)"
        )

        val names = availableEngines.map {
            if (it.packageName == activeEngine) {
                "${it.label}  ✓"
            } else {
                it.label
            }
        }.toTypedArray()

        val selectedIndex = availableEngines.indexOfFirst {
            it.packageName == activeEngine
        }.coerceAtLeast(0)

        AlertDialog.Builder(this)
            .setTitle("ВЫБОР TTS-ДВИЖКА")
            .setSingleChoiceItems(
                names,
                selectedIndex
            ) { dialog, which ->
                val selected = availableEngines[which]
                dialog.dismiss()
                switchEngine(selected.packageName)
            }
            .setNegativeButton("НАЗАД", null)
            .show()
    }

    private fun switchEngine(packageName: String) {
        if (packageName == activeEngine && qwenSelected == (packageName == QWEN_ENGINE)) return

        if (exporting) {
            toast("Нельзя переключить движок во время экспорта")
            return
        }

        val wasSpeaking = speaking
        val resumePosition = currentPosition

        playbackToken++
        stopTtsOnly()

        if (packageName == QWEN_ENGINE) {
            qwenSelected = true
            activeEngine = QWEN_ENGINE
            speechPrefs.edit().putString(ENGINE_PREF, QWEN_ENGINE).apply()
            statusText.text = "Qwen3-TTS · проверка модели..."
            ensureQwenLoaded {
                statusText.text = "Qwen3-TTS готов"
                if (wasSpeaking) startPlaybackAt(resumePosition)
            }
            return
        }

        qwenSelected = false
        resumeAfterEngineInit = wasSpeaking
        engineResumePosition = resumePosition

        ttsReady = false
        statusText.text = "Переключение TTS..."

        initializeEngine(packageName)
    }

    private fun initializeEngine(packageName: String?) {
        engineInitToken++
        val token = engineInitToken

        ttsReady = false

        if (::tts.isInitialized) {
            try {
                tts.stop()
                tts.shutdown()
            } catch (_: Exception) {
            }
        }

        val listener = TextToSpeech.OnInitListener { status ->
            runOnUiThread {
                if (token != engineInitToken ||
                    isFinishing ||
                    isDestroyed
                ) {
                    return@runOnUiThread
                }

                handleEngineInit(status, packageName)
            }
        }

        try {
            tts = if (packageName.isNullOrBlank()) {
                TextToSpeech(this, listener)
            } else {
                TextToSpeech(this, listener, packageName)
            }
        } catch (e: Exception) {
            ttsReady = false
            resumeAfterEngineInit = false
            statusText.text = "Ошибка создания TTS-движка"
            toast("Не удалось создать TTS-движок")
        }
    }

    private fun handleEngineInit(
        status: Int,
        packageName: String?
    ) {
        if (status != TextToSpeech.SUCCESS) {
            ttsReady = false
            resumeAfterEngineInit = false
            statusText.text = "Ошибка подключения TTS"
            toast("Не удалось запустить выбранный движок")
            return
        }

        activeEngine = packageName ?: try {
            tts.defaultEngine ?: ""
        } catch (e: Exception) {
            ""
        }

        availableEngines = discoverEngines()

        if (packageName == null) {
            val savedEngine = speechPrefs.getString(
                ENGINE_PREF,
                null
            )

            // Qwen is an in-app engine, not an Android TextToSpeech service.
            // Restore it before the Android engine preference can overwrite it.
            if (savedEngine == QWEN_ENGINE) {
                ttsReady = true
                activeEngine = QWEN_ENGINE
                loadVoices()
                installPlaybackListener()
                qwenSelected = true
                statusText.text = if (qwen.isModelDownloaded()) {
                    "Qwen3-TTS · модель загружена"
                } else {
                    "Qwen3-TTS · модель не скачана"
                }
                if (qwen.isModelDownloaded()) {
                    ensureQwenLoaded {
                        statusText.text = "Qwen3-TTS готов"
                    }
                }
                return
            }

            val preferredEngine = when {
                savedEngine != null &&
                    availableEngines.any {
                        it.packageName == savedEngine
                    } -> savedEngine

                availableEngines.any {
                    it.packageName == HAYAI_ENGINE
                } -> HAYAI_ENGINE

                else -> activeEngine
            }

            if (preferredEngine.isNotBlank() &&
                preferredEngine != activeEngine &&
                availableEngines.any {
                    it.packageName == preferredEngine
                }
            ) {
                switchEngine(preferredEngine)
                return
            }
        }

        ttsReady = true

        speechPrefs.edit()
            .putString(ENGINE_PREF, activeEngine)
            .apply()

        loadVoices()
        installPlaybackListener()

        qwenSelected = false
        statusText.text = engineStatusText()

        if (resumeAfterEngineInit) {
            val position = engineResumePosition
            resumeAfterEngineInit = false

            mainHandler.postDelayed({
                if (ttsReady && !exporting) {
                    startPlaybackAt(position)
                }
            }, 250L)
        }
    }

    private fun engineStatusText(): String {
        return "${engineLabel(activeEngine)} · ${voices.size} голосов"
    }


    // ====================================================
    // QWEN3-TTS: МОДЕЛЬ, ВОСПРОИЗВЕДЕНИЕ И WAV
    // ====================================================

    private fun showQwenModelDialog() {
        val downloaded = qwen.isModelDownloaded()
        val options = arrayOf(
            if (downloaded) "ПЕРЕСКАЧАТЬ МОДЕЛЬ (~884 МБ)" else "СКАЧАТЬ МОДЕЛЬ (~884 МБ)",
            "ЗАГРУЗИТЬ МОДЕЛЬ В ПАМЯТЬ",
            "УДАЛИТЬ МОДЕЛЬ"
        )
        AlertDialog.Builder(this)
            .setTitle("QWEN3-TTS · УПРАВЛЕНИЕ МОДЕЛЬЮ")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> downloadQwenModel()
                    1 -> ensureQwenLoaded {
                        toast("Qwen3-TTS готов к работе")
                    }
                    2 -> AlertDialog.Builder(this)
                        .setTitle("Удалить модель?")
                        .setMessage("Будут удалены оба файла модели (около 884 МБ).")
                        .setNegativeButton("ОТМЕНА", null)
                        .setPositiveButton("УДАЛИТЬ") { _, _ ->
                            executor.execute {
                                try {
                                    qwen.deleteModel()
                                    qwenReady = false
                                    runOnUiThread {
                                        toast("Модель Qwen удалена")
                                        statusText.text = "Qwen3-TTS · модель отсутствует"
                                    }
                                } catch (e: Exception) {
                                    runOnUiThread { toast(e.message ?: "Ошибка удаления") }
                                }
                            }
                        }.show()
                }
            }
            .setNegativeButton("НАЗАД", null)
            .show()
    }

    private fun downloadQwenModel() {
        if (exporting || qwenBusy) {
            toast("Дождись завершения текущей операции")
            return
        }
        qwenBusy = true
        qwenReady = false
        val progress = ProgressDialog(this).apply {
            setTitle("Загрузка Qwen3-TTS")
            setMessage("Подготовка загрузки...")
            setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
            max = 100
            progress = 0
            setCancelable(false)
            setButton(
                ProgressDialog.BUTTON_NEGATIVE,
                "ОТМЕНА"
            ) { _, _ -> qwen.cancelDownload() }
            show()
        }
        statusText.text = "Загрузка модели Qwen3-TTS..."
        executor.execute {
            try {
                qwen.downloadModel { state ->
                    val percent = state.percent.coerceIn(0, 100)
                    runOnUiThread {
                        if (!isFinishing && !isDestroyed) {
                            progress.progress = percent
                            progress.setMessage(
                                "${state.fileName}\n${percent}%"
                            )
                        }
                    }
                }
                val loaded = qwen.loadModel()
                if (!loaded) throw IllegalStateException("Не удалось загрузить модель")
                runOnUiThread {
                    qwenBusy = false
                    qwenReady = true
                    progress.dismiss()
                    statusText.text = "Qwen3-TTS готов"
                    toast("Модель загружена и готова")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    qwenBusy = false
                    qwenReady = false
                    progress.dismiss()
                    statusText.text = "Ошибка модели Qwen"
                    toast(e.message ?: "Ошибка загрузки Qwen")
                }
            }
        }
    }

    private fun ensureQwenLoaded(onReady: (() -> Unit)? = null) {
        if (qwenReady) {
            onReady?.invoke()
            return
        }
        if (qwenBusy) {
            toast("Qwen3-TTS ещё загружается")
            return
        }
        if (!qwen.isModelDownloaded()) {
            toast("Сначала скачай модель в настройках Qwen3-TTS")
            showQwenModelDialog()
            return
        }
        qwenBusy = true
        statusText.text = "Загрузка Qwen3-TTS в память..."
        executor.execute {
            try {
                qwen.loadModel()
                runOnUiThread {
                    qwenBusy = false
                    qwenReady = true
                    statusText.text = "Qwen3-TTS готов"
                    onReady?.invoke()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    qwenBusy = false
                    qwenReady = false
                    statusText.text = "Ошибка загрузки Qwen"
                    toast(e.message ?: "Не удалось загрузить Qwen")
                }
            }
        }
    }

    private fun qwenLanguageId(): Int {
        return when (selectedLanguageCode.lowercase(Locale.ROOT)) {
            "en" -> 2050
            "fr" -> 2061
            "ru" -> 2069
            else -> 2069
        }
    }

    private fun synthesizeQwenText(text: String): QwenLocalTts.Audio {
        val parts = buildSpeechParts(text, 0)
        if (parts.isEmpty()) throw IllegalArgumentException("Пустой текст")
        val chunks = ArrayList<FloatArray>(parts.size)
        var sampleRate = 0
        var totalSamples = 0
        parts.forEachIndexed { index, part ->
            val audio = qwen.synthesize(
                part.text,
                languageId = qwenLanguageId(),
                maxAudioTokens = 512
            )
            if (sampleRate == 0) sampleRate = audio.sampleRate
            if (sampleRate != audio.sampleRate) {
                throw IllegalStateException("Qwen вернул разные частоты дискретизации")
            }
            chunks.add(audio.samples)
            totalSamples += audio.samples.size
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    statusText.text = "Qwen синтез ${index + 1}/${parts.size}..."
                }
            }
        }
        val merged = FloatArray(totalSamples)
        var offset = 0
        chunks.forEach { chunk ->
            System.arraycopy(chunk, 0, merged, offset, chunk.size)
            offset += chunk.size
        }
        return QwenLocalTts.Audio(merged, sampleRate, totalSamples * 1000L / sampleRate)
    }

    private fun startQwenPlayback(position: Int) {
        if (!qwenReady) {
            ensureQwenLoaded { startPlaybackAt(position) }
            return
        }
        val start = position.coerceIn(0, sourceText.length)
        val text = sourceText.substring(start).trim()
        if (text.isEmpty()) {
            speaking = false
            currentPosition = sourceText.length
            updatePosition(currentPosition)
            statusText.text = "Готово"
            return
        }

        speaking = true
        qwenStartPosition = start
        qwenPlaybackLength = text.length
        statusText.text = "Qwen3-TTS · синтез речи..."
        val token = playbackToken
        executor.execute {
            try {
                val audio = synthesizeQwenText(text)
                val file = File(cacheDir, "qwen_playback_${token}.wav")
                qwen.writeWav(audio, file)
                runOnUiThread {
                    if (token != playbackToken || !speaking || isFinishing || isDestroyed) {
                        file.delete()
                        return@runOnUiThread
                    }
                    qwenAudioFile?.delete()
                    qwenAudioFile = file
                    val player = MediaPlayer()
                    qwenPlayer = player
                    player.setDataSource(file.absolutePath)
                    player.setOnPreparedListener {
                        if (token != playbackToken || !speaking) {
                            it.release()
                            return@setOnPreparedListener
                        }
                        it.start()
                        statusText.text = "Воспроизведение · Qwen3-TTS"
                        startQwenProgressUpdates(token)
                    }
                    player.setOnCompletionListener {
                        stopQwenProgressUpdates()
                        if (token == playbackToken) {
                            speaking = false
                            currentPosition = sourceText.length
                            updatePosition(currentPosition)
                            statusText.text = "Готово · Qwen3-TTS"
                            stopQwenPlayer(deleteFile = false)
                        }
                    }
                    player.setOnErrorListener { _, what, extra ->
                        if (token == playbackToken) {
                            speaking = false
                            statusText.text = "Ошибка воспроизведения Qwen ($what/$extra)"
                            toast("Не удалось воспроизвести аудио Qwen")
                            stopQwenPlayer()
                        }
                        true
                    }
                    player.prepareAsync()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (token == playbackToken) {
                        speaking = false
                        statusText.text = "Ошибка синтеза Qwen"
                        toast(e.message ?: "Ошибка синтеза Qwen")
                    }
                }
            }
        }
    }

    private fun startQwenProgressUpdates(token: Int) {
        stopQwenProgressUpdates()
        val task = object : Runnable {
            override fun run() {
                val player = qwenPlayer
                if (token == playbackToken && speaking && player != null) {
                    try {
                        val duration = player.duration.coerceAtLeast(1)
                        val elapsed = player.currentPosition.coerceIn(0, duration)
                        val fraction = elapsed.toFloat() / duration.toFloat()
                        val charPosition = qwenStartPosition +
                            (qwenPlaybackLength * fraction).toInt()
                        updatePosition(charPosition.coerceIn(0, sourceText.length))
                    } catch (_: Exception) {
                    }
                    mainHandler.postDelayed(this, 250L)
                }
            }
        }
        qwenProgressTask = task
        mainHandler.post(task)
    }

    private fun stopQwenProgressUpdates() {
        qwenProgressTask?.let { mainHandler.removeCallbacks(it) }
        qwenProgressTask = null
    }

    private fun stopQwenPlayer(deleteFile: Boolean = true) {
        stopQwenProgressUpdates()
        try {
            qwenPlayer?.stop()
        } catch (_: Exception) {
        }
        try {
            qwenPlayer?.release()
        } catch (_: Exception) {
        }
        qwenPlayer = null
        if (deleteFile) {
            qwenAudioFile?.delete()
            qwenAudioFile = null
        }
    }

    private fun exportQwenWav(text: String) {
        if (qwenBusy) {
            toast("Qwen3-TTS ещё выполняет операцию")
            return
        }
        ensureQwenLoaded {
            if (exporting) return@ensureQwenLoaded
            exporting = true
            exportToken++
            val token = exportToken
            exportButton.isEnabled = false
            progressBar.visibility = View.VISIBLE
            progressBar.isIndeterminate = true
            statusText.text = "Qwen3-TTS · экспорт WAV..."
            executor.execute {
                val temp = File(cacheDir, "qwen_export_${token}.wav")
                try {
                    val audio = synthesizeQwenText(text)
                    qwen.writeWav(audio, temp)
                    val info = inspectWav(temp)
                    val saved = saveWav(listOf(temp), info.format, info.dataSize)
                    runOnUiThread {
                        if (token == exportToken) {
                            exporting = false
                            exportButton.isEnabled = true
                            progressBar.visibility = View.GONE
                            progressBar.isIndeterminate = false
                            statusText.text = "Qwen3-TTS · WAV сохранён"
                            toast("WAV сохранён в Музыка/CORVUS-S")
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        if (token == exportToken) {
                            exporting = false
                            exportButton.isEnabled = true
                            progressBar.visibility = View.GONE
                            progressBar.isIndeterminate = false
                            statusText.text = "Ошибка экспорта Qwen"
                            toast(e.message ?: "Ошибка экспорта WAV")
                        }
                    }
                } finally {
                    temp.delete()
                }
            }
        }
    }

    // ====================================================
    // ЯЗЫК И ГОЛОС
    // ====================================================

    private fun languagePreferenceKey(): String {
        val engine = activeEngine.ifBlank {
            "system_default"
        }
        return "language_code_$engine"
    }

    private fun voicePreferenceKey(): String {
        val engine = activeEngine.ifBlank {
            "system_default"
        }
        return "voice_name_$engine"
    }

    private fun showLanguageDialog() {
        if (qwenSelected) {
            val codes = listOf("ru", "en", "fr")
            val labels = arrayOf("Русский", "English", "Français")
            val selected = codes.indexOf(selectedLanguageCode).coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle("ЯЗЫК QWEN3-TTS")
                .setSingleChoiceItems(labels, selected) { dialog, which ->
                    selectedLanguageCode = codes[which]
                    speechPrefs.edit()
                        .putString(languagePreferenceKey(), selectedLanguageCode)
                        .apply()
                    dialog.dismiss()
                    toast("Язык Qwen: ${labels[which]}")
                }
                .setNegativeButton("НАЗАД", null)
                .show()
            return
        }
        if (!ttsReady) {
            toast("TTS-движок ещё не готов")
            return
        }

        if (availableLanguages.isEmpty()) {
            toast("Движок не предоставил список языков")
            return
        }

        val names = availableLanguages.map {
            it.displayName
        }.toTypedArray()

        val selectedIndex = availableLanguages.indexOfFirst {
            it.code == selectedLanguageCode
        }.coerceAtLeast(0)

        AlertDialog.Builder(this)
            .setTitle("ВЫБОР ЯЗЫКА")
            .setSingleChoiceItems(
                names,
                selectedIndex
            ) { dialog, which ->
                val selected = availableLanguages[which]
                dialog.dismiss()
                changeLanguage(selected.code)
            }
            .setNegativeButton("НАЗАД", null)
            .show()
    }

    private fun changeLanguage(languageCode: String) {
        if (languageCode == selectedLanguageCode) return

        val wasSpeaking = speaking
        val resumePosition = currentPosition

        if (speaking) {
            playbackToken++
            stopTtsOnly()
        }

        selectedLanguageCode = languageCode

        speechPrefs.edit()
            .putString(languagePreferenceKey(), languageCode)
            .apply()

        loadVoices(languageCode)

        if (wasSpeaking && ttsReady) {
            startPlaybackAt(resumePosition)
        }
    }

    private fun loadVoices(languageCode: String? = null) {
        val allVoices = try {
            tts.voices?.filter {
                it.locale.language.isNotBlank()
            } ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }

        availableLanguages = allVoices
            .map { it.locale }
            .distinctBy { it.language }
            .map { locale ->
                LanguageItem(
                    code = locale.language,
                    locale = locale,
                    displayName = locale.getDisplayName(Locale("ru"))
                )
            }
            .sortedBy { it.displayName }

        val savedLanguage = speechPrefs.getString(
            languagePreferenceKey(),
            speechPrefs.getString("language_code", null)
        )

        if (availableLanguages.isEmpty()) {
            voices = emptyList()
            selectedLanguageCode = savedLanguage ?: "ru"

            voiceSpinner.adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                listOf("Стандартный голос движка")
            )

            ttsReady = true
            statusText.text = engineStatusText()
            return
        }

        val requestedLanguage =
            languageCode ?: savedLanguage ?: "ru"

        selectedLanguageCode = when {
            availableLanguages.any {
                it.code == requestedLanguage
            } -> requestedLanguage

            availableLanguages.any {
                it.code == "ru"
            } -> "ru"

            else -> availableLanguages.first().code
        }

        voices = allVoices
            .filter {
                it.locale.language == selectedLanguageCode
            }
            .distinctBy { it.name }
            .sortedBy { it.name }
            .map {
                VoiceItem(it.name, it)
            }

        if (voices.isEmpty()) {
            voiceSpinner.adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                listOf("Голоса не найдены")
            )

            ttsReady = true
            statusText.text = engineStatusText()
            return
        }

        val savedVoice = speechPrefs.getString(
            voicePreferenceKey(),
            speechPrefs.getString("voice_name", null)
        )

        val savedIndex = voices.indexOfFirst {
            it.name == savedVoice
        }

        val selectedIndex =
            if (savedIndex >= 0) savedIndex else 0

        lastSelectedVoice = selectedIndex

        voiceSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            voices.map { it.name }
        ).also {
            it.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
            )
        }

        voiceSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(
                    parent: AdapterView<*>?
                ) {}

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    if (position !in voices.indices) return

                    val selected = voices[position]

                    speechPrefs.edit()
                        .putString(
                            voicePreferenceKey(),
                            selected.name
                        )
                        .apply()

                    activeVoiceName = selected.name

                    if (ttsReady) {
                        try {
                            tts.setLanguage(selected.voice.locale)
                            tts.voice = selected.voice
                            applySettings()
                        } catch (e: Exception) {
                            statusText.text = "Ошибка выбора голоса"
                            return
                        }
                    }

                    if (lastSelectedVoice != position) {
                        lastSelectedVoice = position

                        if (speaking) {
                            restartAtCurrentPosition()
                        }
                    }
                }
            }

        voiceSpinner.setSelection(selectedIndex)

        val selectedVoice = voices[selectedIndex].voice

        try {
            tts.setLanguage(selectedVoice.locale)
            tts.voice = selectedVoice
            activeVoiceName = selectedVoice.name
        } catch (e: Exception) {
            statusText.text = "Не удалось выбрать голос"
            return
        }

        speechPrefs.edit()
            .putString(languagePreferenceKey(), selectedLanguageCode)
            .putString(voicePreferenceKey(), selectedVoice.name)
            .apply()

        ttsReady = true
        statusText.text = engineStatusText()
    }

    // ====================================================
    // КНОПКИ И ОФОРМЛЕНИЕ
    // ====================================================

    private fun styleRoundButton(button: Button) {
        val density = resources.displayMetrics.density
        val borderWidth = density.toInt().coerceAtLeast(1)

        button.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(35, 224, 0, 32))
            setStroke(
                borderWidth,
                Color.rgb(224, 0, 32)
            )
        }

        button.backgroundTintList = null
        button.backgroundTintMode = null
        button.stateListAnimator = null
        button.setTextColor(Color.WHITE)
        button.minWidth = 0
        button.minHeight = 0
        button.setPadding(0, 0, 0, 0)
        button.isAllCaps = false
    }

    private fun setupButtons() {
        styleRoundButton(playButton)
        styleRoundButton(stopButton)
        styleRoundButton(testButton)
        styleRoundButton(exportButton)
        styleRoundButton(settingsButton)

        settingsButton.setOnClickListener {
            showSettingsDialog()
        }

        playButton.setOnClickListener {
            startPlaybackFromCurrentPosition()
        }

        stopButton.setOnClickListener {
            stopSpeech()
        }

        testButton.setOnClickListener {
            testVoice()
        }

        exportButton.setOnClickListener {
            exportWav()
        }
    }

    // ====================================================
    // ТЕКСТОВОЕ ПОЛЕ
    // ====================================================

    private fun setupTextEditor() {
        editText.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(
                s: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) {}

            override fun onTextChanged(
                s: CharSequence?,
                start: Int,
                before: Int,
                count: Int
            ) {
                charCount.text = "${s?.length ?: 0} / 50000"

                if (!speaking && !seeking) {
                    val length = s?.length ?: 0
                    positionSeekBar.max = length
                    positionSeekBar.progress = 0
                    positionValue.text = "0 / $length"
                    currentPosition = 0
                }
            }

            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    // ====================================================
    // СКОРОСТЬ И ВЫСОТА ТОНА
    // ====================================================

    private fun setupSpeechControls() {
        speedSeekBar.max = 100
        pitchSeekBar.max = 100

        speedSeekBar.progress = speechPrefs
            .getInt("speed", 50)
            .coerceIn(0, 100)

        pitchSeekBar.progress = speechPrefs
            .getInt("pitch", 50)
            .coerceIn(0, 100)

        updateSpeed()
        updatePitch()

        speedSeekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    updateSpeed()

                    if (fromUser) {
                        speechPrefs.edit()
                            .putInt("speed", progress)
                            .apply()
                    }
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            }
        )

        pitchSeekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    updatePitch()

                    if (fromUser) {
                        speechPrefs.edit()
                            .putInt("pitch", progress)
                            .apply()
                    }
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            }
        )
    }

    private fun currentSpeed(): Float {
        return 0.5f + speedSeekBar.progress / 100f
    }

    private fun currentPitch(): Float {
        return 0.5f + pitchSeekBar.progress / 100f
    }

    private fun updateSpeed() {
        speedValue.text = "Скорость: " + String.format(
            Locale.US,
            "%.2f",
            currentSpeed()
        )
    }

    private fun updatePitch() {
        pitchValue.text = "Тембр: " + String.format(
            Locale.US,
            "%.2f",
            currentPitch()
        )
    }

    private fun applySettings(
        autoSpeed: Float = 1f,
        autoPitch: Float = 1f
    ) {
        if (!ttsReady) return

        if (voices.isNotEmpty()) {
            val index = voiceSpinner.selectedItemPosition

            if (index in voices.indices) {
                val selected = voices[index].voice

                try {
                    tts.voice = selected
                    activeVoiceName = selected.name
                } catch (_: Exception) {
                }
            }
        }

        val finalSpeed =
            (currentSpeed() * autoSpeed).coerceIn(0.5f, 2f)

        val finalPitch =
            (currentPitch() * autoPitch).coerceIn(0.5f, 2f)

        tts.setSpeechRate(finalSpeed)
        tts.setPitch(finalPitch)
    }

    // ====================================================
    // ОЧИСТКА ТЕКСТА ДЛЯ TTS
    // ====================================================

    private fun cleanTextForSpeech(text: String): String {
        // Заменяем знаки на символы той же длины,
        // чтобы диапазоны onRangeStart не смещались.
        return text
            .replace('!', '.')
            .replace('¡', '.')
    }

    // ====================================================
    // ПРОСЛУШИВАНИЕ
    // ====================================================

    private fun installPlaybackListener() {
        tts.setOnUtteranceProgressListener(
            object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    val id = utteranceId ?: return

                    runOnUiThread {
                        if (id == currentUtteranceId && speaking) {
                            statusText.text = "Воспроизведение..."
                        }
                    }
                }

                override fun onRangeStart(
                    utteranceId: String?,
                    start: Int,
                    end: Int,
                    frame: Int
                ) {
                    val id = utteranceId ?: return
                    val part = utteranceParts[id] ?: return

                    runOnUiThread {
                        if (id == currentUtteranceId && speaking) {
                            updatePosition(
                                (part.start + start)
                                    .coerceIn(0, sourceText.length)
                            )
                        }
                    }
                }

                override fun onDone(utteranceId: String?) {
                    val id = utteranceId ?: return

                    runOnUiThread {
                        if (id != currentUtteranceId || !speaking) {
                            return@runOnUiThread
                        }

                        val completedPart = utteranceParts.remove(id)

                        if (completedPart != null) {
                            currentPosition = completedPart.end
                            updatePosition(currentPosition)
                        }

                        currentPart = null
                        currentUtteranceId = null
                        scheduleNextPart()
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    handlePlaybackError(utteranceId, "Ошибка TTS")
                }

                override fun onError(
                    utteranceId: String?,
                    errorCode: Int
                ) {
                    handlePlaybackError(
                        utteranceId,
                        "Ошибка TTS: $errorCode"
                    )
                }
            }
        )
    }

    private fun handlePlaybackError(
        utteranceId: String?,
        message: String
    ) {
        val id = utteranceId ?: return

        runOnUiThread {
            if (id == currentUtteranceId) {
                speaking = false
                currentUtteranceId = null
                cancelPendingNextPart()
                statusText.text = message
                toast(message)
            }
        }
    }

    // ====================================================
    // РАЗБИЕНИЕ ТЕКСТА НА ЧАСТИ
    // ====================================================

    private fun buildSpeechParts(
        text: String,
        fromPosition: Int
    ): List<SpeechPart> {
        val result = mutableListOf<SpeechPart>()
        val maxLength = 180
        var start = fromPosition.coerceIn(0, text.length)

        val sentenceMarks = charArrayOf(
            '.', '!', '?', '…', '\n'
        )

        while (start < text.length) {
            while (start < text.length && text[start].isWhitespace()) {
                start++
            }

            if (start >= text.length) break

            val limit = minOf(start + maxLength, text.length)
            var end = limit

            if (limit < text.length) {
                var sentenceEnd = -1

                // Ищем последнюю границу предложения,
                // чтобы не создавать слишком короткие фрагменты.
                for (i in start until limit) {
                    if (text[i] in sentenceMarks) {
                        sentenceEnd = i + 1
                    }
                }

                if (sentenceEnd > start) {
                    end = sentenceEnd
                } else {
                    // Если предложения нет, ищем последний пробел.
                    val wordBreak = text.lastIndexOf(' ', limit - 1)

                    if (wordBreak > start) {
                        end = wordBreak
                    }
                }
            }

            if (end <= start) {
                end = minOf(start + maxLength, text.length)
            }

            val partText = text.substring(start, end).trim()

            if (partText.isNotEmpty()) {
                val actualStart = text.indexOf(partText, start)

                result.add(
                    SpeechPart(
                        partText,
                        actualStart,
                        actualStart + partText.length
                    )
                )
            }

            start = end
        }

        return result
    }

    private fun calculatePauseAfter(
        part: SpeechPart,
        hasMoreText: Boolean
    ): Long {
        if (!hasMoreText) return 0L

        val ending = part.text.trimEnd()

        // Не добавляем длинные искусственные паузы:
        // естественную интонацию и паузы обеспечивает сам TTS.
        return when {
            ending.endsWith("...") || ending.endsWith("…") -> 40L
            ending.endsWith("?") -> 30L
            ending.endsWith("!") -> 20L
            ending.endsWith(";") -> 20L
            ending.endsWith(".") -> 20L
            else -> 0L
        }
    }

    // ====================================================
    // УПРАВЛЕНИЕ ВОСПРОИЗВЕДЕНИЕМ
    // ====================================================

    private fun cancelPendingNextPart(resetPause: Boolean = true) {
        pendingNextPart?.let {
            mainHandler.removeCallbacks(it)
        }

        pendingNextPart = null

        if (resetPause) {
            currentPauseAfterMs = 0L
        }
    }

    private fun scheduleNextPart() {
        if (!speaking || exporting) return

        val delay = currentPauseAfterMs.coerceIn(0L, 1500L)
        cancelPendingNextPart(resetPause = false)

        val token = playbackToken

        if (delay <= 0L) {
            speakNextPart()
            return
        }

        val runnable = Runnable {
            pendingNextPart = null

            if (token == playbackToken && speaking && !exporting) {
                speakNextPart()
            }
        }

        pendingNextPart = runnable
        mainHandler.postDelayed(runnable, delay)
    }

    private fun startPlaybackFromCurrentPosition() {
        if (!ttsReady || exporting) return

        sourceText = editText.text.toString()

        if (sourceText.isBlank()) {
            toast("Введите текст")
            return
        }

        startPlaybackAt(
            currentPosition.coerceIn(0, sourceText.length)
        )
    }

    private fun startPlaybackAt(position: Int) {
        if (!ttsReady || exporting) return

        sourceText = editText.text.toString()

        if (sourceText.isBlank()) {
            toast("Введите текст")
            return
        }

        playbackToken++
        cancelPendingNextPart()
        stopTtsOnly()

        currentPosition = position.coerceIn(0, sourceText.length)
        if (qwenSelected) {
            startQwenPlayback(currentPosition)
            return
        }

        speechParts = buildSpeechParts(sourceText, currentPosition)
        nextPartIndex = 0

        if (speechParts.isEmpty()) {
            speaking = false
            currentPosition = sourceText.length
            updatePosition(currentPosition)
            statusText.text = "Готово"
            return
        }

        speaking = true
        updatePosition(currentPosition)
        speakNextPart()
    }

    private fun speakNextPart() {
        if (!speaking || !ttsReady || exporting) return

        cancelPendingNextPart()

        if (nextPartIndex >= speechParts.size) {
            speaking = false
            currentPart = null
            currentUtteranceId = null
            currentPosition = sourceText.length
            updatePosition(currentPosition)
            statusText.text = "Готово"
            return
        }

        val part = speechParts[nextPartIndex]
        nextPartIndex++
        currentPart = part

        val prepared = try {
            speechCore.prepareSpeech(part.text)
        } catch (e: Exception) {
            null
        }

        val firstSegment = prepared?.segments?.firstOrNull()
        val automaticSpeed = firstSegment?.speed ?: 1f
        val automaticPitch =
            (firstSegment?.pitch ?: 1f).coerceIn(0.5f, 2f)

        applySettings(
            autoSpeed = automaticSpeed,
            autoPitch = automaticPitch
        )

        currentPauseAfterMs = calculatePauseAfter(
            part,
            nextPartIndex < speechParts.size
        )

        val id = "speech_${playbackToken}_${UUID.randomUUID()}"
        currentUtteranceId = id
        utteranceParts[id] = part

        val result = tts.speak(
            cleanTextForSpeech(part.text),
            TextToSpeech.QUEUE_FLUSH,
            Bundle(),
            id
        )

        if (result != TextToSpeech.SUCCESS) {
            speaking = false
            currentUtteranceId = null
            cancelPendingNextPart()
            statusText.text = "Не удалось запустить TTS"
            toast("TTS-движок не смог озвучить текст")
        }
    }

    private fun restartAtCurrentPosition() {
        if (!speaking || exporting) return
        startPlaybackAt(currentPosition)
    }

    private fun pauseForSeeking() {
        if (!speaking) return

        playbackToken++
        cancelPendingNextPart()
        speaking = false
        currentUtteranceId = null
        currentPart = null
        utteranceParts.clear()
        stopQwenPlayer()

        if (::tts.isInitialized) tts.stop()
    }

    private fun stopTtsOnly() {
        cancelPendingNextPart()
        stopQwenPlayer()
        speaking = false
        currentUtteranceId = null
        currentPart = null
        utteranceParts.clear()
        stopQwenPlayer()

        if (::tts.isInitialized) {
            try {
                tts.stop()
            } catch (_: Exception) {
            }
        }

        if (ttsReady && pitchTestRunning) {
            pitchTestRunning = false
            installPlaybackListener()
        }
    }

    private fun stopSpeech() {
        playbackToken++
        resumeAfterEngineInit = false
        stopTtsOnly()
        statusText.text = "Остановлено"
    }

    // ====================================================
    // ПОЗИЦИЯ ЧТЕНИЯ
    // ====================================================

    private fun setupPositionControl() {
        positionSeekBar.max = editText.text.length

        positionSeekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    if (fromUser) {
                        positionValue.text =
                            "$progress / ${sourceText.length}"
                    }
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {
                    seeking = true
                    resumeAfterSeek = speaking

                    if (speaking) {
                        pauseForSeeking()
                    }
                }

                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val position = seekBar?.progress ?: 0
                    seeking = false

                    if (sourceText.isNotEmpty()) {
                        currentPosition =
                            position.coerceIn(0, sourceText.length)

                        updatePosition(currentPosition)

                        if (resumeAfterSeek) {
                            startPlaybackAt(currentPosition)
                        }
                    }

                    resumeAfterSeek = false
                }
            }
        )
    }

    private fun updatePosition(position: Int) {
        val safePosition = position.coerceIn(0, sourceText.length)
        currentPosition = safePosition

        if (positionSeekBar.max != sourceText.length) {
            positionSeekBar.max = sourceText.length
        }

        if (!seeking) {
            positionSeekBar.progress = safePosition
        }

        positionValue.text =
            "$safePosition / ${sourceText.length}"
    }

    // ====================================================
    // ТЕСТ ВЫСОТЫ ГОЛОСА
    // ====================================================

    private fun testVoice() {
        if (!ttsReady || exporting) return

        playbackToken++
        stopTtsOnly()

        pitchTestRunning = true
        pitchTestIndex = 0

        tts.setSpeechRate(1f)
        statusText.text = "ТЕСТ ВЫСОТЫ ГОЛОСА"

        tts.setOnUtteranceProgressListener(
            object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    runOnUiThread {
                        if (!pitchTestRunning) return@runOnUiThread
                        pitchTestIndex++
                        speakPitchTestStep()
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    runOnUiThread {
                        finishPitchTest("Ошибка диагностического теста")
                    }
                }

                override fun onError(
                    utteranceId: String?,
                    errorCode: Int
                ) {
                    runOnUiThread {
                        finishPitchTest("Ошибка TTS: $errorCode")
                    }
                }
            }
        )

        speakPitchTestStep()
    }

    private fun speakPitchTestStep() {
        if (!pitchTestRunning) return

        val values = listOf(0.5f, 1f, 2f)

        if (pitchTestIndex >= values.size) {
            finishPitchTest("Тест высоты завершён")
            return
        }

        val pitch = values[pitchTestIndex]
        tts.setSpeechRate(1f)
        tts.setPitch(pitch)

        val phrase = when (pitchTestIndex) {
            0 -> "Первый тест. Низкий голос."
            1 -> "Второй тест. Обычный голос."
            else -> "Третий тест. Высокий голос."
        }

        statusText.text = "Проверка высоты: $pitch"

        val result = tts.speak(
            phrase,
            TextToSpeech.QUEUE_FLUSH,
            Bundle(),
            "pitch_test_${pitchTestIndex}_${UUID.randomUUID()}"
        )

        if (result != TextToSpeech.SUCCESS) {
            finishPitchTest("Не удалось запустить тест")
        }
    }

    private fun finishPitchTest(message: String) {
        if (!pitchTestRunning) return

        pitchTestRunning = false
        tts.setSpeechRate(currentSpeed())
        tts.setPitch(currentPitch())
        installPlaybackListener()
        statusText.text = message
    }

    // ====================================================
    // ЭКСПОРТ WAV
    // ====================================================

    private fun exportWav() {
        if (!ttsReady || exporting) return

        val text = editText.text.toString().trim()

        if (text.isEmpty()) {
            toast("Введите текст")
            return
        }

        if (qwenSelected) {
            exportQwenWav(text)
            return
        }

        playbackToken++
        stopTtsOnly()

        val parts = buildSpeechParts(text, 0)

        if (parts.isEmpty()) return

        val selectedUserPitch = currentPitch()

        val preparedSegments = try {
            parts.map { part ->
                val prepared = speechCore.prepareSpeech(part.text)

                prepared.segments.firstOrNull()
                    ?: throw Exception("Не удалось подготовить просодию")
            }
        } catch (e: Exception) {
            toast(e.message ?: "Ошибка подготовки просодии")
            return
        }

        exporting = true
        exportToken++

        val token = exportToken

        tempFiles.clear()

        val files = parts.indices.map {
            File(cacheDir, "corvus_${token}_$it.wav")
        }

        tempFiles.addAll(files)

        progressBar.visibility = View.VISIBLE
        progressBar.max = parts.size
        progressBar.progress = 0

        exportButton.isEnabled = false
        statusText.text = "Подготовка голоса..."

        val formats = mutableListOf<ByteArray>()
        var index = 0
        var totalSize = 0L

        fun finishFailure(message: String) {
            runOnUiThread {
                if (token != exportToken) return@runOnUiThread

                exporting = false
                files.forEach { it.delete() }
                exportButton.isEnabled = true
                progressBar.visibility = View.GONE

                applySettings()
                installPlaybackListener()

                statusText.text = message
                toast(message)
            }
        }

        lateinit var synthesizeNext: () -> Unit

        synthesizeNext = {
            if (token == exportToken &&
                exporting &&
                index < parts.size
            ) {
                val segment = preparedSegments[index]

                applySettings(
                    autoSpeed = segment.speed,
                    autoPitch = 1f / selectedUserPitch
                )

                statusText.text =
                    "Синтез ${index + 1}/${parts.size}..."

                val result = tts.synthesizeToFile(
                    cleanTextForSpeech(parts[index].text),
                    Bundle(),
                    files[index],
                    "corvus_export_${token}_$index"
                )

                if (result != TextToSpeech.SUCCESS) {
                    finishFailure("Ошибка синтеза WAV")
                }
            }
        }

        tts.setOnUtteranceProgressListener(
            object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    if (token != exportToken) return

                    val completedIndex = index

                    executor.execute {
                        try {
                            val segment =
                                preparedSegments[completedIndex]

                            val adjustedPitchCurve =
                                segment.prosody.pitchCurve.map { point ->
                                    point.copy(
                                        pitch = (
                                            point.pitch * selectedUserPitch
                                        ).coerceIn(0.5f, 1.5f)
                                    )
                                }

                            val adjustedPlan = segment.prosody.copy(
                                pitchCurve = adjustedPitchCurve
                            )

                            runOnUiThread {
                                if (token == exportToken) {
                                    statusText.text =
                                        "Обработка аудио ${completedIndex + 1}/${parts.size}..."
                                }
                            }

                            val rawWav =
                                files[completedIndex].readBytes()

                            val processed = wavProcessor.processWav(
                                input = rawWav,
                                plan = adjustedPlan,
                                settings = segment.audioSettings
                            )

                            if (!processed.success) {
                                throw Exception(processed.message)
                            }

                            files[completedIndex].writeBytes(
                                processed.wavData
                            )

                            val info =
                                inspectWav(files[completedIndex])

                            if (formats.isNotEmpty() &&
                                !formats[0].contentEquals(info.format)
                            ) {
                                throw Exception("Различается формат WAV")
                            }

                            if (formats.isEmpty()) {
                                formats.add(info.format)
                            }

                            totalSize += info.dataSize
                            index++

                            runOnUiThread {
                                if (token != exportToken) {
                                    return@runOnUiThread
                                }

                                progressBar.progress = index

                                if (index < parts.size) {
                                    synthesizeNext()
                                } else {
                                    statusText.text =
                                        "Сборка обработанного WAV..."

                                    executor.execute {
                                        try {
                                            saveWav(
                                                files,
                                                formats[0],
                                                totalSize
                                            )

                                            runOnUiThread {
                                                if (token != exportToken) {
                                                    return@runOnUiThread
                                                }

                                                exporting = false
                                                files.forEach { it.delete() }

                                                exportButton.isEnabled = true
                                                progressBar.visibility =
                                                    View.GONE

                                                applySettings()
                                                installPlaybackListener()

                                                statusText.text =
                                                    "LILL VOICE ENGINE READY"

                                                toast(
                                                    "Обработанный голос сохранён!"
                                                )
                                            }
                                        } catch (e: Exception) {
                                            finishFailure(
                                                e.message
                                                    ?: "Ошибка сохранения WAV"
                                            )
                                        }
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            finishFailure(
                                e.message ?: "Ошибка обработки аудио"
                            )
                        }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    finishFailure("Ошибка синтеза")
                }

                override fun onError(
                    utteranceId: String?,
                    errorCode: Int
                ) {
                    finishFailure("Ошибка TTS: $errorCode")
                }
            }
        )

        synthesizeNext()
    }

    // ====================================================
    // ЧТЕНИЕ WAV
    // ====================================================

    private fun inspectWav(file: File): WavInfo {
        RandomAccessFile(file, "r").use { raf ->
            if (raf.length() < 44) {
                throw Exception("Некорректный WAV")
            }

            val header = ByteArray(12)
            raf.readFully(header)

            if (String(header, 0, 4) != "RIFF" ||
                String(header, 8, 4) != "WAVE"
            ) {
                throw Exception("Некорректный WAV")
            }

            var format: ByteArray? = null
            var offset = -1L
            var size = -1L

            while (raf.filePointer + 8 <= raf.length()) {
                val chunk = ByteArray(8)
                raf.readFully(chunk)

                val id = String(chunk, 0, 4)

                val length = ByteBuffer.wrap(chunk, 4, 4)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .int.toLong() and 0xFFFFFFFFL

                val start = raf.filePointer

                if (start + length > raf.length()) {
                    throw Exception("Повреждён WAV")
                }

                when (id) {
                    "fmt " -> {
                        if (length < 16) {
                            throw Exception("Ошибка формата WAV")
                        }

                        format = ByteArray(16)
                        raf.readFully(format!!)
                    }

                    "data" -> {
                        offset = start
                        size = length
                    }
                }

                raf.seek(start + length + length % 2)
            }

            val fmt = format ?: throw Exception("Нет WAV fmt")

            if (offset < 0 || size < 0) {
                throw Exception("Нет WAV data")
            }

            val b = ByteBuffer.wrap(fmt)
                .order(ByteOrder.LITTLE_ENDIAN)

            val audioFormat = b.getShort(0).toInt() and 0xFFFF
            val channels = b.getShort(2).toInt() and 0xFFFF
            val rate = b.getInt(4)
            val bits = b.getShort(14).toInt() and 0xFFFF

            if (audioFormat != 1 ||
                channels <= 0 ||
                rate <= 0 ||
                bits != 16
            ) {
                throw Exception("Требуется PCM WAV 16-bit")
            }

            return WavInfo(fmt, offset, size)
        }
    }

    // ====================================================
    // СОХРАНЕНИЕ WAV
    // ====================================================

    private fun saveWav(
        files: List<File>,
        format: ByteArray,
        totalSize: Long
    ): Uri {
        require(totalSize <= Int.MAX_VALUE - 36L)

        val values = ContentValues().apply {
            put(
                MediaStore.Audio.Media.DISPLAY_NAME,
                "CORVUS_${System.currentTimeMillis()}.wav"
            )
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
            put(
                MediaStore.Audio.Media.RELATIVE_PATH,
                Environment.DIRECTORY_MUSIC + "/CORVUS-S"
            )
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }

        val uri = contentResolver.insert(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            values
        ) ?: throw Exception("Не удалось создать WAV")

        try {
            val output = contentResolver.openOutputStream(uri)
                ?: throw Exception("Не удалось открыть WAV")

            output.use { out ->
                out.write("RIFF".toByteArray())
                writeIntLE(out, (36L + totalSize).toInt())
                out.write("WAVE".toByteArray())
                out.write("fmt ".toByteArray())
                writeIntLE(out, 16)
                out.write(format)
                out.write("data".toByteArray())
                writeIntLE(out, totalSize.toInt())

                val buffer = ByteArray(65536)

                files.forEach { file ->
                    val info = inspectWav(file)

                    RandomAccessFile(file, "r").use { raf ->
                        raf.seek(info.dataOffset)
                        var remaining = info.dataSize

                        while (remaining > 0) {
                            val count = minOf(
                                buffer.size.toLong(),
                                remaining
                            ).toInt()

                            raf.readFully(buffer, 0, count)
                            out.write(buffer, 0, count)
                            remaining -= count
                        }
                    }
                }
            }

            val complete = ContentValues().apply {
                put(MediaStore.Audio.Media.IS_PENDING, 0)
            }

            contentResolver.update(uri, complete, null, null)
            return uri

        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private fun writeIntLE(
        out: OutputStream,
        value: Int
    ) {
        out.write(value and 255)
        out.write(value shr 8 and 255)
        out.write(value shr 16 and 255)
        out.write(value shr 24 and 255)
    }

    // ====================================================
    // СЛУЖЕБНОЕ
    // ====================================================

    private fun toast(message: String) {
        Toast.makeText(
            this,
            message,
            Toast.LENGTH_SHORT
        ).show()
    }

    override fun onDestroy() {
        engineInitToken++
        exportToken++
        playbackToken++

        resumeAfterEngineInit = false
        cancelPendingNextPart()

        exporting = false
        speaking = false
        pitchTestRunning = false
        ttsReady = false

        tempFiles.forEach {
            it.delete()
        }

        tempFiles.clear()

        if (::tts.isInitialized) {
            try {
                tts.stop()
                tts.shutdown()
            } catch (_: Exception) {
            }
        }

        if (::wavUiController.isInitialized) {
            wavUiController.release()
        }
        stopQwenPlayer()
        if (::qwen.isInitialized) qwen.close()

        executor.shutdownNow()
        super.onDestroy()
    }
}