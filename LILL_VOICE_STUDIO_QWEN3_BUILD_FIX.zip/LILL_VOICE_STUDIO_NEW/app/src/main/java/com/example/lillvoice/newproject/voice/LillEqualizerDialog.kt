package com.example.lillvoice.newproject.voice

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import java.util.Locale

class LillEqualizerDialog(
    private val context: Context,
    private val player: LillWavPlayer,
    private val settings: LillEqualizerSettings
) {

    companion object {
        private const val BLACK = 0xFF090909.toInt()
        private const val PANEL = 0xFF151014.toInt()
        private const val RED = 0xFFE00020.toInt()
        private const val DARK_RED = 0xFF681020.toInt()
        private const val WHITE = 0xFFFFFFFF.toInt()
        private const val GREY = 0xFFBBBBBB.toInt()
    }

    private val bandNames = arrayOf(
        "31 Гц",
        "62 Гц",
        "125 Гц",
        "250 Гц",
        "500 Гц",
        "1 кГц",
        "2 кГц",
        "4 кГц",
        "8 кГц",
        "16 кГц"
    )

    private val bandSeekBars = mutableListOf<SeekBar>()
    private val bandValueLabels = mutableListOf<TextView>()

    private lateinit var enabledSwitch: Switch
    private lateinit var presetSpinner: Spinner
    private lateinit var preampSeekBar: SeekBar
    private lateinit var preampValueLabel: TextView

    private var updatingControls = false
    private var spinnerInitialized = false

    private var dialog: AlertDialog? = null

    fun show() {

        bandSeekBars.clear()
        bandValueLabels.clear()

        updatingControls = false
        spinnerInitialized = false

        applySavedSettingsToPlayer()

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = roundedBackground(PANEL, DARK_RED, 24)
        }

        val scrollView = ScrollView(context).apply {
            isFillViewport = true
            clipToPadding = false

            addView(
                root,
                ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }

        enabledSwitch = Switch(context).apply {
            text = "Эквалайзер включён"
            textSize = 16f
            setTextColor(WHITE)
            isChecked = settings.isEnabled()

            if (android.os.Build.VERSION.SDK_INT >= 21) {
                thumbTintList = ColorStateList(
                    arrayOf(
                        intArrayOf(android.R.attr.state_checked),
                        intArrayOf()
                    ),
                    intArrayOf(RED, 0xFF777777.toInt())
                )

                trackTintList = ColorStateList(
                    arrayOf(
                        intArrayOf(android.R.attr.state_checked),
                        intArrayOf()
                    ),
                    intArrayOf(
                        0xFF8B2033.toInt(),
                        0xFF444444.toInt()
                    )
                )
            }
        }

        enabledSwitch.setOnCheckedChangeListener { _, checked ->

            if (updatingControls) return@setOnCheckedChangeListener

            settings.setEnabled(checked)
            player.setEqualizerEnabled(checked)
        }

        root.addView(
            enabledSwitch,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(48)
            )
        )

        addDivider(root)
        addSectionTitle(root, "Предустановки")

        presetSpinner = Spinner(context).apply {
            background = roundedBackground(
                0xFF211419.toInt(),
                DARK_RED,
                12
            )

            setPopupBackgroundDrawable(
                roundedBackground(PANEL, DARK_RED, 12)
            )
        }

        val adapter = object : ArrayAdapter<String>(
            context,
            android.R.layout.simple_spinner_item,
            LillEqualizerSettings.PRESETS
        ) {

            override fun getView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {

                return styledSpinnerText(
                    getItem(position) ?: "",
                    convertView
                )
            }

            override fun getDropDownView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {

                return styledSpinnerText(
                    getItem(position) ?: "",
                    convertView,
                    true
                )
            }
        }

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        presetSpinner.adapter = adapter

        root.addView(
            presetSpinner,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(48)
            )
        )

        presetSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {

                    if (!spinnerInitialized) {
                        spinnerInitialized = true
                        return
                    }

                    if (updatingControls) return

                    val preset =
                        LillEqualizerSettings.PRESETS[position]

                    if (settings.applyPreset(preset)) {
                        refreshBandControls()
                        applySavedSettingsToPlayer()
                    }
                }

                override fun onNothingSelected(
                    parent: AdapterView<*>?
                ) {
                }
            }

        addDivider(root)
        addSectionTitle(root, "Частотные полосы")

        for (index in 0 until LillEqualizerSettings.BAND_COUNT) {
            addBandControl(root, index)
        }

        addDivider(root)
        addSectionTitle(root, "Предусиление")

        preampValueLabel = TextView(context).apply {
            textSize = 14f
            gravity = Gravity.END
            setTextColor(WHITE)
        }

        preampSeekBar = createStyledSeekBar().apply {
            max = 240
            progress = gainToProgress(settings.getPreamp())
        }

        preampSeekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {

                    val value = progressToGain(progress)

                    preampValueLabel.text = formatGain(value)

                    if (fromUser && !updatingControls) {
                        settings.setPreamp(value)
                        player.setPreamp(value)
                    }
                }

                override fun onStartTrackingTouch(
                    seekBar: SeekBar?
                ) {
                }

                override fun onStopTrackingTouch(
                    seekBar: SeekBar?
                ) {
                }
            }
        )

        root.addView(preampValueLabel)
        root.addView(preampSeekBar)

        updatePreampLabel()

        val builder = AlertDialog.Builder(context)
            .setTitle("Эквалайзер")
            .setView(scrollView)
            .setPositiveButton("Готово", null)
            .setNegativeButton("Закрыть", null)
            .setNeutralButton("Сбросить", null)

        dialog = builder.create()

        dialog?.setOnShowListener {

            val currentDialog =
                dialog ?: return@setOnShowListener

            currentDialog.window?.setBackgroundDrawable(
                roundedBackground(BLACK, RED, 26)
            )

            currentDialog.window?.setDimAmount(0.78f)

            currentDialog.getButton(AlertDialog.BUTTON_POSITIVE)
                ?.setTextColor(RED)

            currentDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                ?.setTextColor(GREY)

            currentDialog.getButton(AlertDialog.BUTTON_NEUTRAL)
                ?.setTextColor(RED)

            currentDialog.getButton(AlertDialog.BUTTON_NEUTRAL)
                ?.setOnClickListener {
                    resetEqualizer()
                }

            currentDialog.window?.setLayout(
                (context.resources.displayMetrics.widthPixels * 0.92f).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        dialog?.show()

        val currentPreset = settings.getPreset()

        val presetIndex =
            LillEqualizerSettings.PRESETS.indexOf(currentPreset)

        if (presetIndex >= 0) {
            presetSpinner.setSelection(presetIndex)
        }
    }

    private fun styledSpinnerText(
        value: String,
        convertView: View?,
        dropdown: Boolean = false
    ): TextView {

        val text = (convertView as? TextView) ?: TextView(context)

        text.text = value
        text.textSize = 14f
        text.setTextColor(WHITE)
        text.gravity = Gravity.CENTER_VERTICAL
        text.setPadding(dp(12), dp(8), dp(12), dp(8))

        if (dropdown) {
            text.setBackgroundColor(PANEL)
            text.minHeight = dp(44)
        }

        return text
    }

    private fun addBandControl(
        parent: LinearLayout,
        index: Int
    ) {

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(5), 0, dp(5))
        }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val name = TextView(context).apply {
            text = bandNames[index]
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(WHITE)
        }

        val valueLabel = TextView(context).apply {
            textSize = 13f
            gravity = Gravity.END
            setTextColor(0xFFFFA0AE.toInt())
        }

        header.addView(
            name,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        header.addView(
            valueLabel,
            LinearLayout.LayoutParams(
                dp(80),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        val seekBar = createStyledSeekBar().apply {
            max = 240
            progress = gainToProgress(
                settings.getBandLevel(index)
            )
        }

        seekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {

                    val gain = progressToGain(progress)

                    valueLabel.text = formatGain(gain)

                    if (fromUser && !updatingControls) {
                        settings.setBandLevel(index, gain)

                        player.setEqualizerBandLevel(
                            index,
                            gain
                        )
                    }
                }

                override fun onStartTrackingTouch(
                    seekBar: SeekBar?
                ) {
                }

                override fun onStopTrackingTouch(
                    seekBar: SeekBar?
                ) {
                }
            }
        )

        valueLabel.text = formatGain(
            settings.getBandLevel(index)
        )

        container.addView(header)
        container.addView(seekBar)

        parent.addView(
            container,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        bandSeekBars.add(seekBar)
        bandValueLabels.add(valueLabel)
    }

    private fun createStyledSeekBar(): SeekBar {

        return SeekBar(context).apply {

            if (android.os.Build.VERSION.SDK_INT >= 21) {
                progressTintList = ColorStateList.valueOf(RED)

                progressBackgroundTintList =
                    ColorStateList.valueOf(0xFF49202A.toInt())

                thumbTintList =
                    ColorStateList.valueOf(0xFFFF5368.toInt())
            }
        }
    }

    private fun refreshBandControls() {

        updatingControls = true

        for (index in 0 until LillEqualizerSettings.BAND_COUNT) {

            val value = settings.getBandLevel(index)

            bandSeekBars[index].progress =
                gainToProgress(value)

            bandValueLabels[index].text =
                formatGain(value)
        }

        preampSeekBar.progress =
            gainToProgress(settings.getPreamp())

        updatePreampLabel()

        updatingControls = false
    }

    private fun applySavedSettingsToPlayer() {

        player.setEqualizerEnabled(
            settings.isEnabled()
        )

        val levels = settings.getAllBandLevels()

        for (index in levels.indices) {
            player.setEqualizerBandLevel(
                index,
                levels[index]
            )
        }

        player.setPreamp(
            settings.getPreamp()
        )
    }

    private fun resetEqualizer() {

        settings.reset()

        updatingControls = true

        enabledSwitch.isChecked = settings.isEnabled()

        refreshBandControls()

        val flatIndex =
            LillEqualizerSettings.PRESETS.indexOf("Ровный")

        if (flatIndex >= 0) {
            presetSpinner.setSelection(flatIndex)
        }

        updatingControls = false

        applySavedSettingsToPlayer()
    }

    private fun updatePreampLabel() {

        preampValueLabel.text = formatGain(
            settings.getPreamp()
        )
    }

    private fun addSectionTitle(
        parent: LinearLayout,
        text: String
    ) {

        val title = TextView(context).apply {
            this.text = text
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(RED)
            setPadding(0, dp(10), 0, dp(8))
        }

        parent.addView(title)
    }

    private fun addDivider(parent: LinearLayout) {

        val divider = View(context).apply {
            background = GradientDrawable().apply {
                setColor(DARK_RED)
                cornerRadius = dp(2).toFloat()
            }
        }

        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(1)
        )

        params.topMargin = dp(8)
        params.bottomMargin = dp(8)

        parent.addView(divider, params)
    }

    private fun roundedBackground(
        color: Int,
        strokeColor: Int,
        radius: Int
    ): GradientDrawable {

        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), strokeColor)
        }
    }

    private fun gainToProgress(value: Float): Int {

        return ((value.coerceIn(-12f, 12f) + 12f) * 10f)
            .toInt()
            .coerceIn(0, 240)
    }

    private fun progressToGain(progress: Int): Float {

        return (progress.coerceIn(0, 240) / 10f) - 12f
    }

    private fun formatGain(value: Float): String {

        return String.format(
            Locale.US,
            "%+.1f dB",
            value
        )
    }

    private fun dp(value: Int): Int {

        return (
            value * context.resources.displayMetrics.density
        ).toInt()
    }
}
