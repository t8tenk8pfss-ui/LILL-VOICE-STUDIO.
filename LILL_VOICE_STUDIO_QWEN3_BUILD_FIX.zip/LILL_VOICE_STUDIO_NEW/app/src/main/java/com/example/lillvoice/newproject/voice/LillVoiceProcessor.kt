package com.example.lillvoice.newproject.voice

import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.PI

/**
 * LILL VOICE PROCESSOR
 *
 * Тембральная обработка голоса:
 * - мягкое усиление нижней середины;
 * - деликатная глубина;
 * - сглаживание резких верхних частот;
 * - контроль громкости и пиков;
 * - энергетическая кривая просодии.
 *
 * Входной сигнал Float PCM: от -1.0 до 1.0.
 */
class LillVoiceProcessor {

    data class AudioSettings(
        val volume: Float = 1.0f,
        val warmth: Float = 0.75f,
        val softness: Float = 0.80f,
        val depth: Float = 0.65f,
        val limiterThreshold: Float = 0.95f
    )

    /**
     * Состояние фильтров для одного аудиоканала.
     */
    private class FilterState {
        var warmthLow = 0f
        var depthLow = 0f
        var softnessLow = 0f
    }

    /**
     * Основная обработка PCM.
     */
    fun process(
        input: FloatArray,
        settings: AudioSettings = AudioSettings()
    ): FloatArray {

        if (input.isEmpty()) return FloatArray(0)

        val output = FloatArray(input.size)
        val state = FilterState()

        val volume = settings.volume.coerceIn(0f, 2f)
        val threshold = settings.limiterThreshold.coerceIn(0.1f, 1f)

        val warmth = settings.warmth.coerceIn(0f, 1f)
        val softness = settings.softness.coerceIn(0f, 1f)
        val depth = settings.depth.coerceIn(0f, 1f)

        for (i in input.indices) {

            val original = input[i]

            val shaped = processTone(
                sample = original,
                state = state,
                warmth = warmth,
                softness = softness,
                depth = depth
            )

            val sample = shaped * volume

            output[i] = applyLimiter(
                sample = sample,
                threshold = threshold,
                softness = softness
            )
        }

        return output
    }

    /**
     * Тембральная обработка одного отсчёта.
     *
     * Используются три сглаживающих фильтра:
     * 1. Нижняя середина — тепло.
     * 2. Низкая составляющая — глубина.
     * 3. Верхняя составляющая — мягкость.
     */
    private fun processTone(
        sample: Float,
        state: FilterState,
        warmth: Float,
        softness: Float,
        depth: Float
    ): Float {

        // Тёплая нижняя середина.
        state.warmthLow +=
            0.075f * (sample - state.warmthLow)

        // Более низкая составляющая для глубины.
        state.depthLow +=
            0.018f * (sample - state.depthLow)

        // Сглаженная версия сигнала для контроля верхов.
        state.softnessLow +=
            0.32f * (sample - state.softnessLow)

        // Добавляем немного тёплой середины.
        val warmthAmount = warmth * 0.12f

        // Деликатная глубина без чрезмерного баса.
        val depthAmount = depth * 0.055f

        // Уменьшаем резкие высокочастотные составляющие.
        val highFrequency = sample - state.softnessLow
        val softnessAmount = softness * 0.10f

        var result = sample

        result += state.warmthLow * warmthAmount
        result += state.depthLow * depthAmount
        result -= highFrequency * softnessAmount

        return result
    }

    /**
     * Обработка с энергетической кривой просодии.
     */
    fun processWithEnergyCurve(
        input: FloatArray,
        settings: AudioSettings,
        curve: List<LillProsodyEngine.CurvePoint>
    ): FloatArray {

        if (input.isEmpty()) return FloatArray(0)
        if (curve.isEmpty()) return process(input, settings)

        val output = FloatArray(input.size)
        val state = FilterState()

        val sortedCurve = curve.sortedBy { it.position }

        val volume = settings.volume.coerceIn(0f, 2f)
        val threshold = settings.limiterThreshold.coerceIn(0.1f, 1f)

        val warmth = settings.warmth.coerceIn(0f, 1f)
        val softness = settings.softness.coerceIn(0f, 1f)
        val depth = settings.depth.coerceIn(0f, 1f)

        for (i in input.indices) {

            val position = if (input.size <= 1) {
                0f
            } else {
                i.toFloat() / (input.size - 1)
            }

            val energy = interpolateEnergy(
                position,
                sortedCurve
            )

            val multiplier = energy.coerceIn(0f, 1.5f)

            // Сначала формируем тембр.
            val shaped = processTone(
                sample = input[i],
                state = state,
                warmth = warmth,
                softness = softness,
                depth = depth
            )

            // Затем применяем динамику фразы.
            val sample = shaped * volume * multiplier

            output[i] = applyLimiter(
                sample = sample,
                threshold = threshold,
                softness = softness
            )
        }

        return output
    }

    /**
     * Линейная интерполяция энергетической кривой.
     */
    private fun interpolateEnergy(
        position: Float,
        curve: List<LillProsodyEngine.CurvePoint>
    ): Float {

        if (curve.size == 1) {
            return curve.first().energy
        }

        if (position <= curve.first().position) {
            return curve.first().energy
        }

        if (position >= curve.last().position) {
            return curve.last().energy
        }

        for (i in 0 until curve.lastIndex) {

            val left = curve[i]
            val right = curve[i + 1]

            if (position >= left.position &&
                position <= right.position
            ) {

                val distance = (
                    (position - left.position) /
                        (right.position - left.position)
                            .coerceAtLeast(0.0001f)
                    ).coerceIn(0f, 1f)

                val smooth = distance * distance *
                    (3f - 2f * distance)

                return left.energy +
                    (right.energy - left.energy) * smooth
            }
        }

        return 1f
    }

    /**
     * Мягкий лимитер без резкого обрезания сигнала.
     */
    private fun applyLimiter(
        sample: Float,
        threshold: Float,
        softness: Float
    ): Float {

        val magnitude = abs(sample)

        if (magnitude <= threshold) {
            return sample.coerceIn(-1f, 1f)
        }

        val sign = if (sample < 0f) -1f else 1f

        val excess = magnitude - threshold

        val range = (1f - threshold)
            .coerceAtLeast(0.001f)

        val saturation = (
            excess / range
        ).coerceIn(0f, 1f)

        val curve = 1f -
            (1f - saturation).pow(2f)

        val strength = (
            0.5f + softness.coerceIn(0f, 1f) * 0.5f
        )

        val compressed = threshold +
            range * curve * strength

        return compressed.coerceAtMost(1f) * sign
    }

    /**
     * Float PCM -> PCM16.
     */
    fun toPcm16(input: FloatArray): ShortArray {

        return ShortArray(input.size) { index ->

            val sample = input[index]
                .coerceIn(-1f, 1f)

            (sample * 32767f).toInt().toShort()
        }
    }

    /**
     * PCM16 -> Float PCM.
     */
    fun fromPcm16(input: ShortArray): FloatArray {

        return FloatArray(input.size) { index ->
            input[index].toFloat() / 32768f
        }
    }

    /**
     * Создание настроек из голосового профиля.
     */
    fun settingsFrom(
        profile: LillVoiceProfile,
        emotion: LillEmotionEngine.Emotion,
        intensity: Float
    ): AudioSettings {

        val voice = profile.settingsFor(
            emotion,
            intensity
        )

        return AudioSettings(
            volume = 1.0f,
            warmth = voice.warmth,
            softness = voice.softness,
            depth = voice.depth,
            limiterThreshold = 0.95f
        )
    }

    /**
     * Плавное изменение громкости внутри аудиофрагмента.
     */
    fun applyFade(
        input: FloatArray,
        fadeInSamples: Int,
        fadeOutSamples: Int
    ): FloatArray {

        if (input.isEmpty()) return FloatArray(0)

        val output = input.copyOf()

        val fadeIn = fadeInSamples.coerceIn(0, input.size)
        val fadeOut = fadeOutSamples.coerceIn(0, input.size)

        for (i in output.indices) {

            var gain = 1f

            if (fadeIn > 0 && i < fadeIn) {

                val progress = i.toFloat() /
                    fadeIn.coerceAtLeast(1)

                gain *= sin(
                    progress * (PI / 2.0)
                ).toFloat()
            }

            val remaining = output.size - 1 - i

            if (fadeOut > 0 && remaining < fadeOut) {

                val progress = remaining.toFloat() /
                    fadeOut.coerceAtLeast(1)

                gain *= sin(
                    progress * (PI / 2.0)
                ).toFloat()
            }

            output[i] *= gain
        }

        return output
    }
}
