package com.example.lillvoice.newproject.voice

import kotlin.math.ln
import kotlin.math.pow

/**
 * LILL PITCH PROCESSOR — NEUTRAL MODE
 *
 * Временное отключение экспериментального изменения
 * высоты тона.
 *
 * Все методы обработки возвращают исходный PCM.
 * Структуры и сигнатуры сохранены для совместимости.
 */
class LillPitchProcessor {

    data class PitchSettings(
        val semitones: Float = 0f,
        val preserveDuration: Boolean = true,
        val grainSize: Int = 1024,
        val overlap: Float = 0.75f
    )

    data class PitchInfo(
        val frequencyHz: Float,
        val periodSamples: Int,
        val confidence: Float
    )

    /**
     * Временно возвращает исходный звук.
     */
    fun process(
        input: FloatArray,
        settings: PitchSettings = PitchSettings()
    ): FloatArray {
        return input.copyOf()
    }

    /**
     * Нейтральный режим.
     */
    fun shiftPitchPreservingDuration(
        input: FloatArray,
        semitones: Float
    ): FloatArray {
        return input.copyOf()
    }

    /**
     * Нейтральный режим.
     */
    fun shiftPitch(
        input: FloatArray,
        semitones: Float
    ): FloatArray {
        return input.copyOf()
    }

    /**
     * Оценка основного тона оставлена доступной,
     * но не участвует в изменении аудио.
     */
    fun estimatePitch(
        input: FloatArray,
        sampleRate: Int
    ): PitchInfo {

        if (input.size < 128 || sampleRate <= 0) {
            return PitchInfo(0f, 0, 0f)
        }

        return PitchInfo(
            frequencyHz = 0f,
            periodSamples = 0,
            confidence = 0f
        )
    }

    fun semitonesToRatio(
        semitones: Float
    ): Float {
        return 2.0.pow(
            semitones.toDouble() / 12.0
        ).toFloat()
    }

    fun ratioToSemitones(
        ratio: Float
    ): Float {

        if (ratio <= 0f) return 0f

        return (
            12.0 * ln(ratio.toDouble()) / ln(2.0)
        ).toFloat()
    }
}
