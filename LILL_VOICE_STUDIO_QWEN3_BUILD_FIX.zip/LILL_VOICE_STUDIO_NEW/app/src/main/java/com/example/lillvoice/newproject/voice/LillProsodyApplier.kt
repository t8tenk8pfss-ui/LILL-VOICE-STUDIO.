package com.example.lillvoice.newproject.voice

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * LILL PROSODY APPLIER
 *
 * Изменение высоты голоса с сохранением длительности.
 *
 * 1. Интерполяция просодической кривой.
 * 2. Изменение высоты отдельных аудиофрагментов.
 * 3. WSOLA для сохранения длительности.
 * 4. Плавное перекрытие фрагментов.
 * 5. Финальная обработка громкости.
 */
class LillProsodyApplier {

    data class ProcessingResult(
        val audio: FloatArray,
        val originalSamples: Int,
        val processedSamples: Int,
        val durationPreserved: Boolean
    )

    private val voiceProcessor = LillVoiceProcessor()

    fun apply(
        input: FloatArray,
        plan: LillProsodyEngine.ProsodyPlan,
        settings: LillVoiceProcessor.AudioSettings,
        sampleRate: Int = 24000
    ): FloatArray {

        if (input.isEmpty()) return FloatArray(0)

        val safeSampleRate = sampleRate.coerceIn(8000, 192000)

        val curve = plan.pitchCurve

        val output = if (
            input.size < safeSampleRate / 12 ||
            curve.isEmpty()
        ) {
            input.copyOf()
        } else if (!hasVariablePitch(curve)) {

            pitchShift(
                input = input,
                pitchFactor = getAveragePitch(curve),
                sampleRate = safeSampleRate
            )

        } else {

            processVariablePitch(
                input = input,
                curve = curve,
                sampleRate = safeSampleRate
            )
        }

        return voiceProcessor.process(
            input = output,
            settings = settings
        )
    }

    fun processWithInfo(
        input: FloatArray,
        plan: LillProsodyEngine.ProsodyPlan,
        settings: LillVoiceProcessor.AudioSettings,
        sampleRate: Int = 24000
    ): ProcessingResult {

        val output = apply(
            input = input,
            plan = plan,
            settings = settings,
            sampleRate = sampleRate
        )

        return ProcessingResult(
            audio = output,
            originalSamples = input.size,
            processedSamples = output.size,
            durationPreserved = input.size == output.size
        )
    }

    /**
     * Проверяем, действительно ли кривая меняет высоту
     * по ходу фразы.
     */
    private fun hasVariablePitch(
        curve: List<LillProsodyEngine.CurvePoint>
    ): Boolean {

        if (curve.size < 2) return false

        val values = curve.map { it.pitch }

        val difference = values.maxOrNull()!! -
            values.minOrNull()!!

        return difference > 0.003f
    }

    /**
     * Обработка переменной высоты небольшими блоками.
     */
    private fun processVariablePitch(
        input: FloatArray,
        curve: List<LillProsodyEngine.CurvePoint>,
        sampleRate: Int
    ): FloatArray {

        if (input.isEmpty()) return FloatArray(0)

        val frameSize = (
            sampleRate * 0.45f
        ).roundToInt().coerceAtLeast(1024)

        val overlap = (
            sampleRate * 0.09f
        ).roundToInt().coerceAtLeast(128)

        val hop = (frameSize - overlap).coerceAtLeast(1)

        val output = FloatArray(input.size)
        val weights = FloatArray(input.size)

        var frameStart = 0

        while (frameStart < input.size) {

            val frameEnd = min(
                frameStart + frameSize,
                input.size
            )

            val actualSize = frameEnd - frameStart

            if (actualSize <= 0) break

            val frame = input.copyOfRange(
                frameStart,
                frameEnd
            )

            val centerPosition = (
                frameStart + actualSize * 0.5f
            ) / input.size.toFloat()

            val pitch = getPitchAt(
                curve = curve,
                position = centerPosition
            )

            val processedFrame = pitchShift(
                input = frame,
                pitchFactor = pitch,
                sampleRate = sampleRate
            )

            for (i in processedFrame.indices) {

                val outputIndex = frameStart + i

                if (outputIndex >= output.size) break

                var weight = 1f

                // Плавный вход, если перед этим был блок.
                if (frameStart > 0 && i < overlap) {

                    weight = min(
                        weight,
                        (i + 1).toFloat() /
                            (overlap + 1)
                    )
                }

                // Плавный выход, если после блока будет следующий.
                if (
                    frameEnd < input.size &&
                    i >= actualSize - overlap
                ) {

                    val remaining = actualSize - i

                    val fadeOut = remaining.toFloat() /
                        (overlap + 1)

                    weight = min(weight, fadeOut)
                }

                output[outputIndex] +=
                    processedFrame[i] * weight

                weights[outputIndex] += weight
            }

            frameStart += hop
        }

        for (i in output.indices) {

            if (weights[i] > 0.0001f) {
                output[i] /= weights[i]
            } else {
                output[i] = input[i]
            }
        }

        return output
    }

    /**
     * Интерполяция высоты между точками кривой.
     */
    private fun getPitchAt(
        curve: List<LillProsodyEngine.CurvePoint>,
        position: Float
    ): Float {

        if (curve.isEmpty()) return 1f

        val points = curve.sortedBy { it.position }

        if (points.size == 1) {
            return points.first().pitch.coerceIn(0.70f, 1.35f)
        }

        val x = position.coerceIn(0f, 1f)

        if (x <= points.first().position) {
            return points.first().pitch.coerceIn(0.70f, 1.35f)
        }

        if (x >= points.last().position) {
            return points.last().pitch.coerceIn(0.70f, 1.35f)
        }

        for (i in 0 until points.lastIndex) {

            val left = points[i]
            val right = points[i + 1]

            if (x >= left.position && x <= right.position) {

                val distance = right.position - left.position

                if (distance <= 0.0001f) {
                    return left.pitch.coerceIn(0.70f, 1.35f)
                }

                val fraction = (
                    (x - left.position) / distance
                ).coerceIn(0f, 1f)

                return (
                    left.pitch +
                        (right.pitch - left.pitch) * fraction
                ).coerceIn(0.70f, 1.35f)
            }
        }

        return 1f
    }

    private fun getAveragePitch(
        curve: List<LillProsodyEngine.CurvePoint>
    ): Float {

        if (curve.isEmpty()) return 1f

        val points = curve.sortedBy { it.position }

        if (points.size == 1) {
            return points.first().pitch.coerceIn(0.70f, 1.35f)
        }

        var weightedSum = 0f
        var totalWeight = 0f

        for (i in 0 until points.lastIndex) {

            val left = points[i]
            val right = points[i + 1]

            val distance = (
                right.position - left.position
            ).coerceAtLeast(0f)

            val average = (
                left.pitch + right.pitch
            ) * 0.5f

            weightedSum += average * distance
            totalWeight += distance
        }

        val result = if (totalWeight > 0.0001f) {
            weightedSum / totalWeight
        } else {
            points.map { it.pitch }.average().toFloat()
        }

        return result.coerceIn(0.70f, 1.35f)
    }

    /**
     * Изменение высоты с сохранением размера сигнала.
     */
    private fun pitchShift(
        input: FloatArray,
        pitchFactor: Float,
        sampleRate: Int
    ): FloatArray {

        if (input.isEmpty()) return FloatArray(0)

        val factor = pitchFactor.coerceIn(0.70f, 1.35f)

        if (abs(factor - 1f) < 0.005f) {
            return input.copyOf()
        }

        val windowSize = getWindowSize(sampleRate)

        val intermediate = resampleForPitch(
            input = input,
            factor = factor
        )

        // Для слишком короткого сигнала WSOLA нестабилен.
        // Сохраняем исходный звук, а не выдаём WAV другой длины.
        if (intermediate.size < windowSize * 2) {
            return input.copyOf()
        }

        return wsolaTimeStretch(
            input = intermediate,
            targetSize = input.size,
            sampleRate = sampleRate
        )
    }

    private fun getWindowSize(sampleRate: Int): Int {

        return (
            sampleRate * 0.040f
        ).roundToInt()
            .coerceIn(256, 2048)
            .let {
                if (it % 2 == 0) it else it - 1
            }
    }

    /**
     * Ресемплинг для изменения высоты.
     */
    private fun resampleForPitch(
        input: FloatArray,
        factor: Float
    ): FloatArray {

        if (input.isEmpty()) return FloatArray(0)

        val outputSize = max(
            1,
            (input.size / factor).roundToInt()
        )

        val output = FloatArray(outputSize)

        for (i in output.indices) {

            val sourcePosition = i * factor

            val index = sourcePosition.toInt()
                .coerceIn(0, input.lastIndex)

            val nextIndex = min(
                index + 1,
                input.lastIndex
            )

            val fraction = sourcePosition - index

            output[i] = input[index] +
                (input[nextIndex] - input[index]) * fraction
        }

        return output
    }

    /**
     * WSOLA — восстановление исходной длительности.
     */
    private fun wsolaTimeStretch(
        input: FloatArray,
        targetSize: Int,
        sampleRate: Int
    ): FloatArray {

        if (targetSize <= 0) return FloatArray(0)
        if (input.isEmpty()) return FloatArray(targetSize)

        if (input.size == targetSize) {
            return input.copyOf()
        }

        val windowSize = getWindowSize(sampleRate)

        if (input.size < windowSize * 2) {
            return input.copyOf()
        }

        val synthesisHop = windowSize / 2
        val overlap = windowSize - synthesisHop

        val stretchRatio = targetSize.toFloat() /
            input.size.toFloat()

        val searchRadius = (
            sampleRate * 0.005f
        ).roundToInt().coerceAtLeast(8)

        val output = FloatArray(targetSize)
        val weights = FloatArray(targetSize)

        addFrame(
            output = output,
            weights = weights,
            input = input,
            inputStart = 0,
            outputStart = 0,
            windowSize = windowSize,
            overlap = overlap
        )

        var outputStart = synthesisHop

        while (outputStart < targetSize) {

            val expectedInputStart = (
                outputStart / stretchRatio
            ).roundToInt()

            val candidate = findBestMatch(
                input = input,
                output = output,
                weights = weights,
                expectedPosition = expectedInputStart,
                outputPosition = outputStart,
                overlap = overlap,
                searchRadius = searchRadius
            )

            addFrame(
                output = output,
                weights = weights,
                input = input,
                inputStart = candidate,
                outputStart = outputStart,
                windowSize = windowSize,
                overlap = overlap
            )

            outputStart += synthesisHop
        }

        for (i in output.indices) {

            if (weights[i] > 0.0001f) {
                output[i] /= weights[i]
            }
        }

        return output
    }

    private fun findBestMatch(
        input: FloatArray,
        output: FloatArray,
        weights: FloatArray,
        expectedPosition: Int,
        outputPosition: Int,
        overlap: Int,
        searchRadius: Int
    ): Int {

        val maxStart = input.size - overlap - 1

        if (maxStart <= 0) return 0

        val start = (
            expectedPosition - searchRadius
        ).coerceIn(0, maxStart)

        val end = (
            expectedPosition + searchRadius
        ).coerceIn(0, maxStart)

        var bestPosition = expectedPosition.coerceIn(
            0,
            maxStart
        )

        var bestScore = -Float.MAX_VALUE

        val step = if (searchRadius > 100) 2 else 1

        for (candidate in start..end step step) {

            var dot = 0.0
            var energyA = 0.0
            var energyB = 0.0

            var count = 0

            for (j in 0 until overlap) {

                val outIndex = outputPosition + j

                if (outIndex >= output.size) break

                val weight = weights[outIndex]

                if (weight <= 0.0001f) continue

                val a = output[outIndex] / weight
                val b = input[candidate + j]

                dot += a.toDouble() * b.toDouble()
                energyA += a.toDouble() * a.toDouble()
                energyB += b.toDouble() * b.toDouble()

                count++
            }

            if (count < overlap / 2) continue

            val denominator = sqrt(
                energyA * energyB
            ).coerceAtLeast(0.0000001)

            val score = (dot / denominator).toFloat()

            if (score > bestScore) {
                bestScore = score
                bestPosition = candidate
            }
        }

        return bestPosition
    }

    private fun addFrame(
        output: FloatArray,
        weights: FloatArray,
        input: FloatArray,
        inputStart: Int,
        outputStart: Int,
        windowSize: Int,
        overlap: Int
    ) {

        for (j in 0 until windowSize) {

            val inputIndex = inputStart + j
            val outputIndex = outputStart + j

            if (inputIndex >= input.size) break
            if (outputIndex >= output.size) break

            val weight = if (j < overlap) {
                (j + 1).toFloat() / (overlap + 1)
            } else {
                1f
            }

            output[outputIndex] += input[inputIndex] * weight
            weights[outputIndex] += weight
        }
    }
}
