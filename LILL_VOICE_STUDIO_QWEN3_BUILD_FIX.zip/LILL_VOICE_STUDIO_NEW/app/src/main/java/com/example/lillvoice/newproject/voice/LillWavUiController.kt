package com.example.lillvoice.newproject.voice

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import com.example.lillvoice.newproject.R
import java.util.Locale

class LillWavUiController(
    private val activity: Activity,
    private val picker: ActivityResultLauncher<Array<String>>
) {

    private var service: LillWavPlaybackService? = null
    private var bound = false

    private lateinit var chooseButton: Button
    private lateinit var playButton: Button
    private lateinit var pauseButton: Button
    private lateinit var stopButton: Button
    private lateinit var equalizerButton: Button

    private lateinit var fileName: TextView
    private lateinit var timeValue: TextView

    private lateinit var positionSeekBar: SeekBar
    private lateinit var speedSeekBar: SeekBar
    private lateinit var pitchSeekBar: SeekBar

    private lateinit var speedValue: TextView
    private lateinit var pitchValue: TextView

    private var seeking = false
    private var durationMs = 0

    private var selectedUri: Uri? = null
    private var selectedFileName = "WAV"

    private var playbackSpeed = 1f
    private var playbackPitch = 1f

    private val serviceConnection = object : ServiceConnection {

        override fun onServiceConnected(
            name: ComponentName?,
            binder: IBinder?
        ) {
            val localBinder =
                binder as? LillWavPlaybackService.LocalBinder
                    ?: return

            service = localBinder.getService()

            service?.setUiListener(serviceListener)

            service?.setSpeed(playbackSpeed)
            service?.setPitch(playbackPitch)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service?.setUiListener(null)
            service = null
            bound = false
        }
    }

    private val serviceListener =
        object : LillWavPlaybackService.UiListener {

            override fun onPrepared(durationMs: Int) {
                this@LillWavUiController.durationMs = durationMs

                positionSeekBar.max = 1000
                positionSeekBar.progress = 0

                updateTime(0, durationMs)
            }

            override fun onProgress(
                positionMs: Int,
                durationMs: Int
            ) {
                this@LillWavUiController.durationMs = durationMs

                if (!seeking) {
                    positionSeekBar.progress =
                        if (durationMs > 0) {
                            (
                                positionMs.toLong() * 1000L /
                                    durationMs
                                ).toInt()
                        } else {
                            0
                        }
                }

                updateTime(positionMs, durationMs)
            }

            override fun onCompleted() {
                positionSeekBar.progress = 1000
                updateTime(durationMs, durationMs)
            }

            override fun onError(message: String) {
                showMessage(message)
            }

            override fun onPlaybackStateChanged(isPlaying: Boolean) {
                // Существующее поведение сохранено.
            }
        }

    // ====================================================
    // ЧЁРНО-КРАСНОЕ ОФОРМЛЕНИЕ КНОПОК
    // ====================================================

    private fun styleWavButton(button: Button) {

        val density = activity.resources.displayMetrics.density

        val backgroundDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE

            // Полностью непрозрачный чёрный фон.
            setColor(Color.rgb(8, 8, 8))

            // Яркая красная окантовка.
            setStroke(
                (2 * density).toInt().coerceAtLeast(1),
                Color.rgb(224, 0, 32)
            )

            cornerRadius = 50f * density
        }

        // Назначаем собственный фон.
        button.background = backgroundDrawable

        // Отключаем системную фиолетовую тонировку.
        button.backgroundTintList = null
        button.backgroundTintMode = null

        // Убираем стандартную анимацию оформления.
        button.stateListAnimator = null

        // Явно задаём цвет символов.
        button.setTextColor(Color.WHITE)

        // Сохраняем читаемость надписей.
        button.isAllCaps = false

        // Убираем системные минимальные размеры и отступы.
        button.minWidth = 0
        button.minHeight = 0
        button.setPadding(0, 0, 0, 0)

        button.invalidate()
    }

    // ====================================================
    // НАСТРОЙКА ПЛЕЕРА
    // ====================================================

    fun setup() {

        chooseButton = activity.findViewById(R.id.wavChooseButton)
        playButton = activity.findViewById(R.id.wavPlayButton)
        pauseButton = activity.findViewById(R.id.wavPauseButton)
        stopButton = activity.findViewById(R.id.wavStopButton)

        equalizerButton =
            activity.findViewById(R.id.wavEqualizerButton)

        fileName = activity.findViewById(R.id.wavFileName)
        timeValue = activity.findViewById(R.id.wavTimeValue)

        positionSeekBar =
            activity.findViewById(R.id.wavPositionSeekBar)

        speedSeekBar =
            activity.findViewById(R.id.wavSpeedSeekBar)

        pitchSeekBar =
            activity.findViewById(R.id.wavPitchSeekBar)

        speedValue = activity.findViewById(R.id.wavSpeedValue)
        pitchValue = activity.findViewById(R.id.wavPitchValue)

        // Применяем оформление ко всем пяти кнопкам.
        styleWavButton(chooseButton)
        styleWavButton(playButton)
        styleWavButton(pauseButton)
        styleWavButton(stopButton)
        styleWavButton(equalizerButton)

        setupButtons()
        setupPosition()
        setupSpeed()
        setupPitch()

        speedSeekBar.progress = 50
        pitchSeekBar.progress = 50

        speedValue.text = "1.00x"
        pitchValue.text = "1.00x"

        positionSeekBar.max = 1000
        positionSeekBar.progress = 0

        updateTime(0, 0)

        val intent = Intent(
            activity,
            LillWavPlaybackService::class.java
        )

        bound = activity.bindService(
            intent,
            serviceConnection,
            Context.BIND_AUTO_CREATE
        )
    }

    private fun setupButtons() {

        chooseButton.setOnClickListener {
            picker.launch(arrayOf("audio/*"))
        }

        playButton.setOnClickListener {
            if (service == null) {
                startServiceAction(
                    LillWavPlaybackService.ACTION_PLAY
                )
            } else {
                service?.play()
            }
        }

        pauseButton.setOnClickListener {
            service?.pause()
                ?: startServiceAction(
                    LillWavPlaybackService.ACTION_PAUSE
                )
        }

        stopButton.setOnClickListener {
            service?.stop()
                ?: startServiceAction(
                    LillWavPlaybackService.ACTION_STOP
                )

            positionSeekBar.progress = 0
            updateTime(0, durationMs)
        }

        // Открытие всплывающего окна эквалайзера.
        equalizerButton.setOnClickListener {

            val currentService = service

            if (currentService != null) {
                currentService.showEqualizer(activity)
            } else {
                showMessage("WAV-плеер ещё подключается")
            }
        }
    }

    // ====================================================
    // ПОЗИЦИЯ ВОСПРОИЗВЕДЕНИЯ
    // ====================================================

    private fun setupPosition() {

        positionSeekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {
                    seeking = true
                }

                override fun onStopTrackingTouch(seekBar: SeekBar?) {

                    val targetPosition =
                        (
                            positionSeekBar.progress.toLong() *
                                durationMs / 1000L
                            ).toInt()

                    service?.seekTo(targetPosition)

                    seeking = false
                }
            }
        )
    }

    // ====================================================
    // СКОРОСТЬ
    // ====================================================

    private fun setupSpeed() {

        speedSeekBar.max = 150
        speedSeekBar.progress = 50

        speedSeekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {

                    val speed = 0.5f + progress / 100f

                    playbackSpeed = speed
                    service?.setSpeed(speed)

                    speedValue.text = String.format(
                        Locale.US,
                        "%.2fx",
                        speed
                    )
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            }
        )
    }

    // ====================================================
    // ВЫСОТА ТОНА
    // ====================================================

    private fun setupPitch() {

        pitchSeekBar.max = 150
        pitchSeekBar.progress = 50

        pitchSeekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {

                    val pitch = 0.5f + progress / 100f

                    playbackPitch = pitch
                    service?.setPitch(pitch)

                    pitchValue.text = String.format(
                        Locale.US,
                        "%.2fx",
                        pitch
                    )
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            }
        )
    }

    // ====================================================
    // ЗАГРУЗКА WAV
    // ====================================================

    fun load(uri: Uri) {

        try {
            activity.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
            // Продолжаем загрузку.
        }

        val name = try {
            activity.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->

                if (cursor.moveToFirst()) {

                    val index = cursor.getColumnIndex(
                        OpenableColumns.DISPLAY_NAME
                    )

                    if (index >= 0) {
                        cursor.getString(index)
                    } else {
                        null
                    }

                } else {
                    null
                }
            }

        } catch (_: Exception) {
            null
        }

        selectedUri = uri

        selectedFileName = name
            ?.takeIf { it.isNotBlank() }
            ?: uri.lastPathSegment
            ?: "WAV"

        fileName.text = selectedFileName

        durationMs = 0
        positionSeekBar.progress = 0
        updateTime(0, 0)

        requestNotificationPermissionIfNeeded()

        val intent = Intent(
            activity,
            LillWavPlaybackService::class.java
        ).apply {

            action = LillWavPlaybackService.ACTION_LOAD

            data = uri

            putExtra(
                LillWavPlaybackService.EXTRA_NAME,
                selectedFileName
            )
        }

        try {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                activity.startForegroundService(intent)
            } else {
                activity.startService(intent)
            }

        } catch (exception: Exception) {

            showMessage(
                exception.message
                    ?: "Не удалось запустить WAV-плеер"
            )
        }
    }

    // ====================================================
    // РАЗРЕШЕНИЕ УВЕДОМЛЕНИЙ
    // ====================================================

    private fun requestNotificationPermissionIfNeeded() {

        if (Build.VERSION.SDK_INT < 33) return

        if (
            activity.checkSelfPermission(
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            activity.requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                7306
            )
        }
    }

    // ====================================================
    // ЗАПУСК СЕРВИСА
    // ====================================================

    private fun startServiceAction(action: String) {

        val intent = Intent(
            activity,
            LillWavPlaybackService::class.java
        ).setAction(action)

        try {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                activity.startForegroundService(intent)
            } else {
                activity.startService(intent)
            }

        } catch (exception: Exception) {

            showMessage(
                exception.message
                    ?: "Ошибка управления плеером"
            )
        }
    }

    // ====================================================
    // ОТОБРАЖЕНИЕ ВРЕМЕНИ
    // ====================================================

    private fun updateTime(
        positionMs: Int,
        durationMs: Int
    ) {

        fun format(ms: Int): String {

            val seconds = ms.coerceAtLeast(0) / 1000
            val minutes = seconds / 60
            val remainingSeconds = seconds % 60

            return String.format(
                Locale.US,
                "%02d:%02d",
                minutes,
                remainingSeconds
            )
        }

        timeValue.text =
            "${format(positionMs)} / ${format(durationMs)}"
    }

    // ====================================================
    // СООБЩЕНИЯ
    // ====================================================

    private fun showMessage(message: String) {

        Toast.makeText(
            activity,
            message,
            Toast.LENGTH_SHORT
        ).show()
    }

    // ====================================================
    // ОСВОБОЖДЕНИЕ РЕСУРСОВ
    // ====================================================

    fun release() {

        service?.setUiListener(null)

        if (bound) {

            try {
                activity.unbindService(serviceConnection)
            } catch (_: Exception) {
            }

            bound = false
        }

        service = null

        // Проигрыватель принадлежит сервису.
        // Здесь его не освобождаем.
    }
}
