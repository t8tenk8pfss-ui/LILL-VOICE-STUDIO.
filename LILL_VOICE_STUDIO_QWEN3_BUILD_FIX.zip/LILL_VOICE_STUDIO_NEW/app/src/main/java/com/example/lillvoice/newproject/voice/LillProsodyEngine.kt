package com.example.lillvoice.newproject.voice

/**
 * LILL PROSODY ENGINE
 *
 * Формирование эмоциональной просодии:
 * - высота голоса;
 * - интонационный контур;
 * - скорость;
 * - энергия;
 * - паузы;
 * - влияние пунктуации.
 */
class LillProsodyEngine {

    enum class ContourType {
        NEUTRAL,
        RISING,
        FALLING,
        RISE_FALL,
        FALL_RISE,
        GENTLE_FALL,
        SUSPENDED,
        EMPHATIC
    }

    enum class PhraseEnding {
        NEUTRAL,
        QUESTION,
        EXCLAMATION,
        ELLIPSIS,
        CONTINUATION
    }

    data class CurvePoint(
        val position: Float,
        val pitch: Float,
        val energy: Float
    )

    data class ProsodyPlan(
        val contour: ContourType,
        val ending: PhraseEnding,
        val speed: Float,
        val intensity: Float,
        val emphasis: Float,
        val pauseBeforeMs: Long,
        val pauseAfterMs: Long,
        val pitchCurve: List<CurvePoint>,
        val energyCurve: List<CurvePoint>
    )

    private val positions = listOf(
        0f,
        0.20f,
        0.45f,
        0.70f,
        1f
    )

    fun createPlan(
        text: String,
        emotion: LillEmotionEngine.Emotion,
        intensity: Float,
        baseSpeed: Float = 1f,
        basePitch: Float = 1f,
        expressiveness: Float = 0.85f
    ): ProsodyPlan {

        val strength = intensity.coerceIn(0f, 1f)
        val expression = expressiveness.coerceIn(0f, 1f)

        val ending = detectEnding(text)

        val contour = selectContour(
            emotion = emotion,
            ending = ending
        )

        val emotionSpeed = when (emotion) {
            LillEmotionEngine.Emotion.CALM -> 1.00f
            LillEmotionEngine.Emotion.JOY -> 1.07f
            LillEmotionEngine.Emotion.SADNESS -> 0.88f
            LillEmotionEngine.Emotion.TENDERNESS -> 0.93f
            LillEmotionEngine.Emotion.IRONY -> 0.98f
            LillEmotionEngine.Emotion.ANGER -> 1.08f
        }

        val finalSpeed = (
            baseSpeed * emotionSpeed
        ).coerceIn(0.65f, 1.25f)

        val pitchBase = basePitch.coerceIn(
            0.70f,
            1.35f
        )

        val pitchAmplitude = (
            0.015f + 0.055f * strength
        ) * expression

        val pitchShape = getPitchShape(contour)

        val pitchCurve = positions.mapIndexed { index, position ->

            val variation = pitchShape[index] * pitchAmplitude

            CurvePoint(
                position = position,
                pitch = (
                    pitchBase * (1f + variation)
                ).coerceIn(0.70f, 1.35f),
                energy = 1f
            )
        }

        val energyShape = getEnergyShape(contour)

        val energyAmplitude = (
            0.04f + 0.12f * strength
        ) * expression

        val energyCurve = positions.mapIndexed { index, position ->

            CurvePoint(
                position = position,
                pitch = 1f,
                energy = (
                    1f + energyShape[index] * energyAmplitude
                ).coerceIn(0.75f, 1.30f)
            )
        }

        val emphasis = when (emotion) {
            LillEmotionEngine.Emotion.CALM -> 0.10f
            LillEmotionEngine.Emotion.JOY -> 0.40f
            LillEmotionEngine.Emotion.SADNESS -> 0.12f
            LillEmotionEngine.Emotion.TENDERNESS -> 0.16f
            LillEmotionEngine.Emotion.IRONY -> 0.50f
            LillEmotionEngine.Emotion.ANGER -> 0.70f
        }

        val endingEmphasis = when (ending) {
            PhraseEnding.QUESTION -> 0.15f
            PhraseEnding.EXCLAMATION -> 0.30f
            PhraseEnding.ELLIPSIS -> 0f
            PhraseEnding.CONTINUATION -> 0.05f
            PhraseEnding.NEUTRAL -> 0f
        }

        val pauseAfter = when (ending) {
            PhraseEnding.QUESTION -> 180L
            PhraseEnding.EXCLAMATION -> 160L
            PhraseEnding.ELLIPSIS -> 320L
            PhraseEnding.CONTINUATION -> 140L
            PhraseEnding.NEUTRAL -> 0L
        }

        return ProsodyPlan(
            contour = contour,
            ending = ending,
            speed = finalSpeed,
            intensity = strength,
            emphasis = (
                emphasis * strength + endingEmphasis
            ).coerceIn(0f, 1f),
            pauseBeforeMs = 0L,
            pauseAfterMs = pauseAfter,
            pitchCurve = pitchCurve,
            energyCurve = energyCurve
        )
    }

    private fun detectEnding(text: String): PhraseEnding {

        val trimmed = text.trimEnd()

        if (trimmed.isEmpty()) {
            return PhraseEnding.NEUTRAL
        }

        if (
            trimmed.endsWith("...") ||
            trimmed.endsWith("…")
        ) {
            return PhraseEnding.ELLIPSIS
        }

        return when (trimmed.last()) {
            '?' , '？' -> PhraseEnding.QUESTION
            '!', '！' -> PhraseEnding.EXCLAMATION
            ',', ';', ':', '—', '-' ->
                PhraseEnding.CONTINUATION

            else -> PhraseEnding.NEUTRAL
        }
    }

    private fun selectContour(
        emotion: LillEmotionEngine.Emotion,
        ending: PhraseEnding
    ): ContourType {

        return when (ending) {

            PhraseEnding.QUESTION ->
                ContourType.RISING

            PhraseEnding.EXCLAMATION ->
                if (emotion == LillEmotionEngine.Emotion.ANGER) {
                    ContourType.EMPHATIC
                } else if (
                    emotion == LillEmotionEngine.Emotion.JOY
                ) {
                    ContourType.RISE_FALL
                } else {
                    ContourType.EMPHATIC
                }

            PhraseEnding.ELLIPSIS ->
                if (
                    emotion == LillEmotionEngine.Emotion.SADNESS ||
                    emotion == LillEmotionEngine.Emotion.TENDERNESS
                ) {
                    ContourType.GENTLE_FALL
                } else {
                    ContourType.SUSPENDED
                }

            PhraseEnding.CONTINUATION ->
                ContourType.SUSPENDED

            PhraseEnding.NEUTRAL ->
                when (emotion) {
                    LillEmotionEngine.Emotion.CALM ->
                        ContourType.GENTLE_FALL

                    LillEmotionEngine.Emotion.JOY ->
                        ContourType.RISE_FALL

                    LillEmotionEngine.Emotion.SADNESS ->
                        ContourType.FALLING

                    LillEmotionEngine.Emotion.TENDERNESS ->
                        ContourType.GENTLE_FALL

                    LillEmotionEngine.Emotion.IRONY ->
                        ContourType.FALL_RISE

                    LillEmotionEngine.Emotion.ANGER ->
                        ContourType.EMPHATIC
                }
        }
    }

    /**
     * Относительные изменения высоты.
     * Значения от -1 до +1.
     */
    private fun getPitchShape(
        contour: ContourType
    ): FloatArray {

        return when (contour) {

            ContourType.NEUTRAL ->
                floatArrayOf(0f, 0f, 0f, -0.15f, -0.20f)

            ContourType.RISING ->
                floatArrayOf(-0.30f, -0.15f, 0f, 0.45f, 0.85f)

            ContourType.FALLING ->
                floatArrayOf(0.30f, 0.15f, 0f, -0.55f, -0.90f)

            ContourType.RISE_FALL ->
                floatArrayOf(0f, 0.55f, 0.85f, 0.35f, -0.55f)

            ContourType.FALL_RISE ->
                floatArrayOf(0.35f, 0.05f, -0.65f, -0.10f, 0.65f)

            ContourType.GENTLE_FALL ->
                floatArrayOf(0.15f, 0.10f, 0f, -0.25f, -0.40f)

            ContourType.SUSPENDED ->
                floatArrayOf(0f, 0.15f, 0.25f, 0.15f, 0.05f)

            ContourType.EMPHATIC ->
                floatArrayOf(-0.40f, 0.75f, 0.30f, -0.35f, -0.70f)
        }
    }

    private fun getEnergyShape(
        contour: ContourType
    ): FloatArray {

        return when (contour) {

            ContourType.NEUTRAL ->
                floatArrayOf(0f, 0f, 0f, -0.10f, -0.15f)

            ContourType.RISING ->
                floatArrayOf(-0.10f, 0f, 0.10f, 0.25f, 0.35f)

            ContourType.FALLING ->
                floatArrayOf(0.25f, 0.15f, 0f, -0.15f, -0.30f)

            ContourType.RISE_FALL ->
                floatArrayOf(0f, 0.30f, 0.40f, 0.15f, -0.15f)

            ContourType.FALL_RISE ->
                floatArrayOf(0.20f, 0f, -0.20f, 0.10f, 0.30f)

            ContourType.GENTLE_FALL ->
                floatArrayOf(0.10f, 0.05f, 0f, -0.10f, -0.20f)

            ContourType.SUSPENDED ->
                floatArrayOf(0f, 0.05f, 0.10f, 0.05f, 0f)

            ContourType.EMPHATIC ->
                floatArrayOf(-0.15f, 0.45f, 0.25f, -0.05f, -0.20f)
        }
    }
}
